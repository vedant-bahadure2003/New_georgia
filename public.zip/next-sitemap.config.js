// next-sitemap.config.js
module.exports = {
  siteUrl: "https://uzbekistanmedi.com",
  generateRobotsTxt: true,
  generateIndexSitemap: false,
  priority: 0.7,
  changefreq: "weekly",
};
