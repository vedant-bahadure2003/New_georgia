import React from "react";
import PopupForm from "@/_components/popupform/PopUp";
const page = () => {
  return (
    <>
      <PopupForm />
    </>
  );
};

export default page;
