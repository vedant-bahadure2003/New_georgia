import React from "react";
import ContactImg from "../../../public/Images/ContactImg.png";
import ContactBgImg from "../../../public/Images/ContactBgImg.png";
import pana from "../../../public/Images/pana.png";
import Image from "next/image";
import { MdCall, MdHome, MdMail } from "react-icons/md"; // Importing new icons

const page = () => {
  return (
    <>
      {/* BgImage */}
      <div className="relative w-full h-[300px] sm:h-[380px]">
        {/* Background Image */}
        <div className="absolute h-[400px] w-full">
          <Image
            src={ContactImg}
            alt="ContactImg"
            className="w-full object-cover block sm:hidden h-[300px]"
          />
          <Image
            src={ContactBgImg}
            alt="ContactBgImg"
            className="w-full h-full object-cover hidden sm:block sm:h-[380px]"
          />
          <div className="h-[300px] sm:h-[380px] w-full absolute top-0 bg-black opacity-60"></div>
        </div>
        <div className="absolute top-20 sm:top-24 text-white left-5 text-sm font-semibold">
          <p>
            Home /<span className="text-[#16A8AF]"> Contact Us</span>
          </p>
        </div>
        {/* Heading */}
        <div className="text-white absolute top-32 sm:top-44 w-[90%] sm:w-[50%] left-5 flex flex-col gap-1">
          <h1 className="text-[24px] sm:text-4xl font-semibold mt-3 w-full">
            Contact Us
          </h1>
        </div>
      </div>
      <div className="w-full flex flex-col items-center justify-center mt-[40px]">
        <div className="p-3 ">
          <h2 className="text-[22px] lg:text-[30px] font-[700]">
            Contact KlickEdu{" "}
            <span className="text-[#16A8AF]">
              {" "}
              #1 MBBS Abroad Consultant from India
            </span>
          </h2>
        </div>
        <div className="w-[85%]  lg:w-[58%] mx-auto xl:h-[550px] h-[1100px] shadow-xl border-gray-100 rounded-md border-t-2 flex xl:flex-row flex-col-reverse items-center justify-center gap-8 xl:gap-6">
          {/* Contact Form */}
          <div className="xl:w-[400px] bg-gradient-to-t from-[#034752] to-[#3FC5DB] h-[500px] flex flex-col items-center justify-evenly rounded-md w-[90%]">
            <input
              type="text"
              placeholder="Name"
              className="w-[80%] h-[45px] rounded-md px-4 outline-none"
            />
            <input
              type="text"
              placeholder="Contact Number"
              className="w-[80%] h-[45px] rounded-md px-4 outline-none"
            />
            <input
              type="email"
              placeholder="Email"
              className="w-[80%] h-[45px] rounded-md px-4 outline-none"
            />
            <select
              defaultValue=""
              className="w-[80%] h-[45px] rounded-md px-4 outline-none bg-white"
            >
              <option value="" disabled>
                Select Your Country
              </option>
              <option value="India">India</option>
              <option value="USA">USA</option>
              <option value="Canada">Canada</option>
            </select>
            <select
              defaultValue=""
              className="w-[80%] h-[45px] rounded-md px-4 outline-none bg-white"
            >
              <option value="" disabled>
                Select Your City
              </option>
              <option value="Mumbai">Mumbai</option>
              <option value="New York">New York</option>
              <option value="Toronto">Toronto</option>
            </select>
            <button className="w-[80%] h-[45px] rounded-md bg-[#16a8af] text-white font-semibold">
              Submit
            </button>
          </div>
          {/* Contact Information */}
          <div className="xl:w-[400px] w-[90%] h-[500px]">
            <div className="w-full h-[180px] flex flex-col gap-4">
              <Image
                src={pana}
                alt="pana"
                className="w-full h-full object-cover"
              />
              <div className="flex flex-col mt-8 gap-4">
                <div className="flex w-[90%] gap-2 mx-auto">
                  <div className="w-[50px] text-white rounded-md h-[50px] bg-[#126775] flex items-center justify-center text-2xl">
                    <MdCall />
                  </div>
                  <div className="w-[80%] mx-auto">
                    <h3 className="font-semibold">Helpline Number</h3>
                    <h3 className="text-[14px]">8111 99 6000</h3>
                  </div>
                </div>
                <div className="flex w-[90%] gap-2 mx-auto">
                  <div className="w-[50px] text-white rounded-md h-[50px] bg-[#126775] flex items-center justify-center text-2xl">
                    <MdHome />
                  </div>
                  <div className="w-[80%] mx-auto">
                    <h3 className="font-semibold">Head Office</h3>
                    <h3 className="text-[14px] ">
                      KlickEdu, 1st Floor, MS Building, behind New Theatre,
                      Aristo, Thampanoor, Thiruvananthapuram, Kerala, 695012.
                    </h3>
                  </div>
                </div>
                <div className="flex w-[90%] gap-2 mx-auto">
                  <div className="w-[50px] text-white rounded-md h-[50px] bg-[#126775] flex items-center justify-center text-2xl">
                    <MdMail />
                  </div>
                  <div className="w-[80%] mx-auto">
                    <h3 className="font-semibold">Mail</h3>
                    <h3 className="text-[14px]">info@klickedu.com</h3>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default page;
