import Head from "next/head";

export const metadata = {
  title: "Contact Us - Uzbekistan Medi",
  description:
    "Have questions? Contact Uzbekistan Medi for expert advice on medical education in Uzbekistan and start your journey to becoming a doctor.",
  alternates: {
    canonical: "/contact-us",
  },
};

export default function ContactLayout({ children }) {
  return (
    <>
      <head>
        <script
          async
          src="https://www.googletagmanager.com/gtag/js?id=G-4XLXF0NJLC"
        />
        <script
          dangerouslySetInnerHTML={{
            __html: `
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
              gtag('config', 'G-4XLXF0NJLC');
            `,
          }}
        />
        <meta
          name="google-site-verification"
          content="b5_sTHm3PNeFczTBuqRp1mfWcWYC3hM2LhvIVT4cWX8"
        />
        <meta
          property="og:image"
          content="https://www.yourwebsite.com/path-to-image.jpg"
        />
        <meta
          property="og:url"
          content="https://uzbekistanmedi.com/contact-us"
        />
        {/* <link rel="canonical" href="https://uzbekistanmedi.com/contact-us" /> */}
      </head>
      <main>
        <div>{children}</div>
      </main>
    </>
  );
}
