import React from "react";
import FacultiesOffered from "@/_components/mbbsinuzbekistan/courses/FacultiesOffered";
import HeroSection from "@/_components/mbbsinuzbekistan/colleges/HeroSection";
import FeeStructure from "@/_components/mbbsinuzbekistan/courses/FeeStructure";
 
import MainForm from "@/_components/mbbsinuzbekistan/MainForm";
const page = () => {
  return (
    <>
      <HeroSection />
      <div className="flex lg:px-[150px]">
        <div className="lg:w-[70%] lg:pr-[50px]">
          <FeeStructure />
          <FacultiesOffered />
        </div>
        <div className="w-[30%] mt-8">
          <MainForm />
        </div>
      </div>
    </>
  );
};

export default page;
