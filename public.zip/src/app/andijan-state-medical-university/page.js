import React from "react";
import HeroSection from "@/_components/mbbsinuzbekistan/colleges/HeroSection";
import Xyz from "@/_components/mbbsinuzbekistan/colleges/Xyz";

import HighLightTable from "@/_components/mbbsinuzbekistan/colleges/HighLightTable";
import WhyStudy from "@/_components/mbbsinuzbekistan/colleges/WhyStudy";
import KeyFacts from "@/_components/mbbsinuzbekistan/colleges/KeyFacts";
import FeesStructure from "@/_components/mbbsinuzbekistan/colleges/FeesStructure";
import Elegibility from "@/_components/mbbsinuzbekistan/colleges/Eligibility";
import Admission from "@/_components/mbbsinuzbekistan/colleges/Admission";
import DocumentReq from "@/_components/mbbsinuzbekistan/colleges/DocumentReq";
import Course from "@/_components/mbbsinuzbekistan/colleges/Course";
import MainForm from "@/_components/mbbsinuzbekistan/MainForm";
import Intake from "@/_components/mbbsinuzbekistan/colleges/Intake";
import CourseOffered from "@/_components/mbbsinuzbekistan/colleges/CourseOffered";
import Faq from "@/_components/mbbsinuzbekistan/colleges/faq";
// import TableOfContent from "@/_components/mbbsinuzbekistan/colleges/TableOfContent";
export default function page() {
  return (
    <>
      <HeroSection />
      <div className="flex lg:px-[150px]">
        <div className="lg:w-[70%] lg:pr-[50px]">
          <Xyz />
          {/* <TableOfContent /> */}

          <HighLightTable />
          {/* <YouTube /> */}
          <WhyStudy />
          <KeyFacts />
          <FeesStructure />
          <Elegibility />
          <Admission />
          <DocumentReq />
          {/* <Course /> */}
          <Intake />
          <CourseOffered />
          <Faq />
        </div>

        <div className="w-[30%] mt-8">
          <MainForm />
        </div>
      </div>
    </>
  );
}
