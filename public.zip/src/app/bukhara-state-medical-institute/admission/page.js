import React from "react";
import AdmissionProcess from "@/_components/bukhara-state-medical-institute/admission/AdmissionProcess";
import HeroSection from "@/_components/bukhara-state-medical-institute/homepage/HeroSection";

import MainForm from "@/_components/mbbsinuzbekistan/MainForm";
const page = () => {
  return (
    <>
      <HeroSection />
      <div className="flex lg:px-[150px]">
        <div className="lg:w-[70%] lg:pr-[50px]">
          <AdmissionProcess />
        </div>
        <div className="w-[30%] mt-8">
          <MainForm />
        </div>
      </div>
    </>
  );
};

export default page;
