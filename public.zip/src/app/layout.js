import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Navbar from "@/_components/navbar";
import Footer from "@/_components/Footer";
import CommonContactForm from "@/_components/contact-form/CommonContactForm";
import WhatsApp from "@/_components/WhatsAppIcon/WhatsApp";
import Head from "next/head";
const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
});

export const metadata = {
  title: "Uzbekistan Medi: MBBS Abroad Consultants in India",
  description:
    "Uzbekistan Medi is a trusted MBBS abroad consultant in India, helping students secure admission to top medical universities with affordable fees.",
  robots: "index, follow",
  viewport: "width=device-width, initial-scale=1",
  // canonical: "https://uzbekistanmedi.com/",
  og: {
    title: "Uzbekistan Medi: MBBS Abroad Consultants in India",
    description:
      "Uzbekistan Medi assists Indian students in securing MBBS admissions abroad in reputed medical universities.",
    type: "website",
    url: "https://uzbekistanmedi.com/",
    // image: "/Images/collegeImg.png",
  },
  googleSiteVerification: "b5_sTHm3PNeFczTBuqRp1mfWcWYC3hM2LhvIVT4cWX8",
  googleAnalyticsID: "G-4XLXF0NJLC",
  metadataBase: new URL("https://uzbekistanmedi.com"),
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        {/* Primary Meta Tags */}
        <link rel="canonical" href={metadata.canonical} />
        <meta name="viewport" content={metadata.viewport} />
        <meta name="robots" content={metadata.robots} />

        <title>{metadata.title}</title>

        {/* Open Graph / Facebook */}
        <meta property="og:title" content={metadata.og.title} />
        <meta property="og:description" content={metadata.og.description} />
        <meta property="og:type" content={metadata.og.type} />
        <meta property="og:url" content={metadata.og.url} />
        <meta property="og:site_name" content="Uzbekistan Medi" />

        {/* <meta property="og:image" content={metadata.og.image} /> */}

        {/* Canonical & Favicon */}

        <link rel="icon" href="/favicon.ico" />

        {/* Google Site Verification */}
        <meta
          name="google-site-verification"
          content={metadata.googleSiteVerification}
        />

        {/* Google Analytics */}
        <script
          async
          src={`https://www.googletagmanager.com/gtag/js?id=${metadata.googleAnalyticsID}`}
        ></script>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
              gtag('config', '${metadata.googleAnalyticsID}');
            `,
          }}
        />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <Navbar />
        <main role="main">{children}</main>
        <WhatsApp />
        <div className="mt-4">
          <CommonContactForm />
        </div>
        <Footer />
      </body>
    </html>
  );
}
