import React from "react";
import Herosection from "@/_components/mbbsinuzbekistan/Herosection";
import Highlight from "@/_components/mbbsinuzbekistan/Highlight";
import Planningform from "@/_components/mbbsinuzbekistan/Planningform";

import Whystudy from "@/_components/mbbsinuzbekistan/Whystudy";
import FeesStructure from "@/_components/mbbsinuzbekistan/FeesStructure";
import Eligibility from "@/_components/mbbsinuzbekistan/Eligibility";
import AdmissionProcess from "@/_components/mbbsinuzbekistan/AdmissionProcess";
import Document from "@/_components/mbbsinuzbekistan/Document";
import Syllabus from "@/_components/mbbsinuzbekistan/Syllabus";
import Intake from "@/_components/mbbsinuzbekistan/Intake";
import Accreditation from "@/_components/mbbsinuzbekistan/Accreditation";
import UzbekistanVsIndiaMbbs from "@/_components/mbbsinuzbekistan/UzbekistanVsIndiaMbbs";
import CourseOffered from "@/_components/mbbsinuzbekistan/CourseOffered";
import CareerScope from "@/_components/mbbsinuzbekistan/CareerScope";
import PassingPercentage from "@/_components/mbbsinuzbekistan/PassingPercentage";
import HostelFacility from "@/_components/mbbsinuzbekistan/HostelFacility";
import UniversitySection from "@/_components/mbbsinuzbekistan/UniversitySection";
import MainForm from "@/_components/mbbsinuzbekistan/MainForm";
import Xyz from "@/_components/mbbsinuzbekistan/Xyz";
import Faq from "@/_components/mbbsinuzbekistan/faq";
const MBBS_Uzbekistan = () => {
  return (
    <div className="w-full">
      <Herosection />
      <div className="flex w-full lg:px-[150px]">
        <div className="lg:w-[70%] mx-3  pr-0 w-full lg:pr-[40px]">
          <Xyz />
          <Highlight />
          {/* <YtFrame /> */}
          <Planningform />
          <Whystudy />
          <FeesStructure />
          <Eligibility />
          <AdmissionProcess />
          <Document />
          <Syllabus />
          <UniversitySection />
          <Intake />
          <Accreditation />
          <UzbekistanVsIndiaMbbs />
          <CourseOffered />
          <CareerScope />

          {/* <HostelFacility /> */}
          <Faq />
        </div>
        <div className="w-[30%] mt-10">
          <MainForm />
        </div>
      </div>
    </div>
  );
};

export default MBBS_Uzbekistan;
