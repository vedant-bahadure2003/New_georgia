import React from "react";
import Head from "next/head";
import Script from "next/script";

// SEO metadata for MBBS in Uzbekistan section
export const metadata = {
  title: "MBBS in Uzbekistan: Fees, Admission 2025, Duration",
  description:
    "Study MBBS in Uzbekistan at top NMC-approved medical universities with low tuition fees for Indian students. Learn about admission, duration, and eligibility.",
  canonical: "https://uzbekistanmedi.com/mbbs-in-uzbekistan",
};

const MBBSLayout = ({ children }) => {
  return (
    <>
      {/* SEO metadata */}
      <Head>
        {/* Google Site Verification Meta Tag */}
        <meta
          name="google-site-verification"
          content="b5_sTHm3PNeFczTBuqRp1mfWcWYC3hM2LhvIVT4cWX8"
        />
        <link
          rel="canonical"
          href="https://uzbekistanmedi.com/mbbs-in-uzbekistan"
        />
        <title>{metadata.title}</title>
        <meta name="description" content={metadata.description} />
      </Head>

      {/* Google Analytics Script (in the body) */}
      <Script
        async
        src="https://www.googletagmanager.com/gtag/js?id=G-4XLXF0NJLC"
      />
      <Script
        id="google-analytics"
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{
          __html: `
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
          gtag('config', 'G-4XLXF0NJLC');
        `,
        }}
      />

      {/* Main content */}
      <main>{children}</main>
    </>
  );
};

export default MBBSLayout;
