import React from "react";

import Services from "@/_components/services/Services";

const page = () => {
  return (
    <>
      <Services />

      {/* <Ourservices /> */}
    </>
  );
};

export default page;
