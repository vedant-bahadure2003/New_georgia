import React from "react";
import Head from "next/head";

// SEO metadata for Our Services section
export const metadata = {
  title: "Our Services - Uzbekistan Medi",
  description:
    "Explore Uzbekistan Medi's expert medical education consultancy services for studying in Uzbekistan. Your journey to a successful medical career starts here!",
  robots: "index, follow",
  canonical: "https://uzbekistanmedi.com/services",
  og: {
    title: "Our Services - Uzbekistan Medi",
    description:
      "Uzbekistan Medi provides expert guidance for Indian students seeking MBBS admissions in Uzbekistan.",
    type: "website",
    url: "https://uzbekistanmedi.com/services",
    image: "/Images/servicesImg.png",
  },
  googleSiteVerification: "b5_sTHm3PNeFczTBuqRp1mfWcWYC3hM2LhvIVT4cWX8",
  googleAnalyticsID: "G-4XLXF0NJLC",
};

const ServicesLayout = ({ children }) => {
  return (
    <>
      <Head>
        {/* Primary Meta Tags */}
        <title>{metadata.title}</title>
        <meta name="description" content={metadata.description} />
        <meta name="robots" content={metadata.robots} />

        {/* Open Graph / Facebook */}
        <meta property="og:title" content={metadata.og.title} />
        <meta property="og:description" content={metadata.og.description} />
        <meta property="og:type" content={metadata.og.type} />
        <meta property="og:url" content={metadata.og.url} />
        <meta property="og:image" content={metadata.og.image} />

        {/* Canonical & Google Site Verification */}
        <link rel="canonical" href={metadata.canonical} />
        <meta
          name="google-site-verification"
          content={metadata.googleSiteVerification}
        />

        {/* Google Analytics */}
        <script
          async
          src={`https://www.googletagmanager.com/gtag/js?id=${metadata.googleAnalyticsID}`}
        ></script>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              window.dataLayer = window.dataLayer || [];
              function gtag(){dataLayer.push(arguments);}
              gtag('js', new Date());
              gtag('config', '${metadata.googleAnalyticsID}');
            `,
          }}
        />
      </Head>

      {/* Main content */}
      <main>{children}</main>
    </>
  );
};

export default ServicesLayout;
