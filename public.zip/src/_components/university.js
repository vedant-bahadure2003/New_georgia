"use client";

import Image from "next/image";
import React, { useRef, useState, useEffect } from "react";
import { IoIosArrowForward, IoIosArrowBack } from "react-icons/io";
import Link from "next/link";
import andijan from "../../public/Andijan State Medical.webp";
import samarkand from "../../public/Samarkand.webp";
import Tashkent from "../../public/Tashkent mediacal academy.webp";
import Bukhara from "../../public/Bukhara State Medical.webp";
import Fergana from "../../public/fergana medical.webp";
import tashkentdental from "../../public/Tashkent dental.webp";

const Univercity = () => {
  const scrollContainerRef = useRef(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false); // Track if left arrow should be shown

  // Function to handle scrolling
  const scrollUniversities = (direction) => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({
        left: direction === "forward" ? 300 : -300,
        behavior: "smooth",
      });
    }
  };

  // Function to check scroll position
  const checkScroll = () => {
    if (scrollContainerRef.current) {
      setCanScrollLeft(scrollContainerRef.current.scrollLeft > 0);
    }
  };

  // Run scroll check on mount and when scrolling
  useEffect(() => {
    const scrollContainer = scrollContainerRef.current;
    if (scrollContainer) {
      scrollContainer.addEventListener("scroll", checkScroll);
      checkScroll(); // Initial check
    }
    return () => {
      if (scrollContainer) {
        scrollContainer.removeEventListener("scroll", checkScroll);
      }
    };
  }, []);

  const colleges = [
    {
      name: "Andijan State Medical Institute",
      fees: "3850 USD",
      duration: "6 years",
      link: "/andijan-state-medical-university",
      image: andijan,
    },
    {
      name: "Samarkand State Medical University",
      fees: "3500 USD",
      duration: "6 years",
      link: "/samarkand-state-medical-university",
      image: samarkand,
    },
    {
      name: "Tashkent Medical Academy",
      fees: "3500 USD",
      duration: "6 years",
      link: "/tashkent-medical-academy",
      image: Tashkent,
    },
    {
      name: "Bukhara State Medical Institute",
      fees: "4500 USD",
      duration: "6 years",
      link: "/bukhara-state-medical-institute",
      image: Bukhara,
    },
    {
      name: "Fergana Medical Institute of Public Health",
      fees: "3500 USD",
      duration: "6 years",
      link: "/fergana-medical-institute",
      image: Fergana,
    },
    {
      name: "Tashkent State Dental Institute",
      fees: "4200 USD",
      duration: "6 years",
      link: "/tashkent-medical-academy",
      image: tashkentdental,
    },
  ];

  return (
    <div className="w-[90%] md:w-[80%] mx-auto mt-[20px] relative">
      <h2 className="text-[24px] md:text-[36px] font-bold text-center">
        Explore{" "}
        <span className="text-[#0da9b0] underline">Medical Universities</span>{" "}
        in Uzbekistan
      </h2>
      <p className="text-center mt-2 text-[16px]">
        We are affiliated with these medical universities
      </p>
      <div className="w-full h-full mt-4 md:mt-10">
        <div
          className="w-full py-7 flex gap-5 overflow-x-auto scrollbar-hide"
          ref={scrollContainerRef}
        >
          {colleges.map((college, index) => (
            <div
              className="w-[270px] flex-shrink-0 border shadow-xl rounded-lg"
              key={index}
            >
              <div className="w-full h-[160px] overflow-hidden">
                <Image
                  src={college.image}
                  alt={college.name}
                  className="w-full h-full object-cover"
                  width={270}
                  height={160}
                />
              </div>
              <div className="p-3 flex flex-col justify-between h-[200px]">
                <h3 className="text-[#005D61] text-[20px] font-semibold">
                  {college.name}
                </h3>
                <p className="mt-2">Fees Structure: {college.fees}</p>
                <p>Duration: {college.duration}</p>
                <div className="flex justify-between mt-4">
                  <button className="bg-[#0da9b0] px-4 py-1.5 font-semibold rounded-md text-white">
                    Apply Now
                  </button>
                  <Link href={college.link}>
                    <button className="border border-[#0da9b0] px-4 py-1.5 font-semibold text-[#0da9b0] rounded-md">
                      Read More
                    </button>
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Backward Scroll Button - Hides initially */}
      {canScrollLeft && (
        <button
          className="absolute left-0 top-[60%] transform -translate-y-1/2 bg-teal-500 p-3 rounded-full text-white shadow-lg"
          onClick={() => scrollUniversities("backward")}
        >
          <IoIosArrowBack className="text-xl" />
        </button>
      )}

      {/* Forward Scroll Button */}
      <button
        className="absolute right-0 top-[60%] transform -translate-y-1/2 bg-teal-500 p-3 rounded-full text-white shadow-lg"
        onClick={() => scrollUniversities("forward")}
      >
        <IoIosArrowForward className="text-xl" />
      </button>
    </div>
  );
};

export default Univercity;
