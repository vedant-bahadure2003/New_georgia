"use client";
import Link from "next/link";
import React, { useState, useEffect, useRef } from "react";
import { IoMdMenu, IoMdClose } from "react-icons/io";
import { IoMdHome, IoMdInformationCircle, IoMdSchool } from "react-icons/io";
import { FaBlog, FaUniversity, FaPhotoVideo, FaPhoneAlt } from "react-icons/fa";
import { RiArrowDropDownLine } from "react-icons/ri";
import Image from "next/image";
import logo from "../../public/logo.webp";

const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState(null);
  const [mobileActiveDropdown, setMobileActiveDropdown] = useState(null);
  const menuRef = useRef(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setActiveDropdown(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const toggleDropdown = (index) => {
    setActiveDropdown(activeDropdown === index ? null : index);
  };

  const toggleMobileDropdown = (index) => {
    setMobileActiveDropdown(mobileActiveDropdown === index ? null : index);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const menuItems = [
    {
      label: "Home",
      href: "/",
      icon: <IoMdHome className="text-xl text-gray-900" />,
    },
    {
      label: "About",
      href: "/about-us",
      icon: <IoMdInformationCircle className="text-xl text-gray-900" />,
    },
    {
      label: "MBBS in Uzbekistan",
      href: "/mbbs-in-uzbekistan",
      icon: <IoMdSchool className="text-xl text-gray-900" />,
    },
    {
      label: "Universities",
      href: "#",
      icon: <FaUniversity className="text-xl text-gray-900" />,
      dropdown: [
        {
          label: "Andijan State Medical Institute",
          href: "/andijan-state-medical-university",
        },
        {
          label: "Samarkand State Medical University",
          href: "/samarkand-state-medical-university",
        },
        {
          label: "Bukhara State Medical Institute",
          href: "/bukhara-state-medical-institute",
        },
        {
          label: "Fergana Medical Institute of Public Health",
          href: "/fergana-medical-institute-of-public-health",
        },
      ],
    },
    {
      label: "Services",
      href: "/our-services",
      icon: <FaBlog className="text-xl text-gray-900" />,
    },
    {
      label: "Contact Us",
      href: "/contact-us",
      icon: <FaPhoneAlt className="text-xl text-gray-900" />,
    },
  ];

  return (
    <header className="w-full lg:h-[81px] bg-white shadow-md shadow-gray-400 fixed top-0 left-0 z-50">
      <nav className="w-[90%] md:w-[80%] mx-auto flex justify-between items-center py-2 md:py-4">
        {/* Logo */}
        <div className="flex">
          <Link href={"/"}>
            <Image
              src={logo}
              alt="Uzbekistan Medi Logo"
              className="w-[130px] h-[45px] object-contain"
              loading="eager"
            />
          </Link>
        </div>

        {/* Desktop Navigation */}
        <div className="hidden xl:flex items-center gap-8">
          <ul
            className="flex flex-wrap gap-4 md:gap-6 mt-2 lg:mt-0"
            ref={menuRef}
          >
            {menuItems.map((item, index) => (
              <li key={index}>
                <div className="relative">
                  {/* <Link
                    href={item.href}
                    onClick={(e) => item.dropdown && e.preventDefault()}
                    className="text-base md:text-lg text-black hover:text-[#14e1eb] cursor-pointer flex items-center gap-1"
                    aria-haspopup={item.dropdown ? "true" : undefined}
                    aria-expanded={
                      activeDropdown === index ? "true" : undefined
                    }
                  >
                    {item.label}
                    {item.dropdown && (
                      <RiArrowDropDownLine
                        className={`text-black text-3xl transition-transform duration-300 ${
                          activeDropdown === index ? "rotate-180" : "rotate-0"
                        }`}
                        onClick={() => toggleDropdown(index)}
                      />
                    )}
                  </Link> */}

                  <Link
                    href={item.href}
                    onClick={(e) => {
                      if (item.dropdown) {
                        e.preventDefault();
                        toggleDropdown(index);
                      }
                    }}
                    className="text-base md:text-lg text-black hover:text-[#14e1eb] cursor-pointer flex items-center gap-1"
                    aria-haspopup={item.dropdown ? "true" : undefined}
                    aria-expanded={
                      activeDropdown === index ? "true" : undefined
                    }
                  >
                    {item.label}
                    {item.dropdown && (
                      <RiArrowDropDownLine
                        className={`text-black text-3xl transition-transform duration-300 ${
                          activeDropdown === index ? "rotate-180" : "rotate-0"
                        }`}
                      />
                    )}
                  </Link>

                  {item.dropdown && activeDropdown === index && (
                    <ul className="absolute left-0 bg-white text-black mt-2 shadow-lg rounded-md z-10 min-w-[200px] max-w-[300px] border">
                      {item.dropdown.map((subItem, subIndex) => (
                        <li key={subIndex} className="whitespace-normal">
                          <Link
                            href={subItem.href}
                            onClick={() => setActiveDropdown(null)}
                            className="block px-4 py-2 text-base text-black hover:bg-gray-200 transition duration-200 ease-in-out"
                          >
                            {subItem.label}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </li>
            ))}
          </ul>
          <button className="text-sm py-2 px-4 bg-[#16A8AF] text-white rounded-md hover:bg-teal-600 transition-colors">
            Apply Now
          </button>
        </div>

        {/* Mobile Menu Button */}
        <div className="flex items-center gap-2 xl:hidden">
          <button className="text-sm py-1 px-3 bg-[#16A8AF] text-white rounded-md hover:bg-teal-600">
            Apply Now
          </button>
          <IoMdMenu
            className="text-black text-3xl cursor-pointer"
            onClick={toggleMobileMenu}
            aria-label="Open menu"
          />
        </div>

        {/* Mobile Navigation */}
        <div
          className={`fixed top-0 left-0 w-full h-screen bg-white z-[60] transform ${
            isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
          } transition-transform duration-200 overflow-y-auto`}
        >
          <div className="flex  justify-between items-center px-4 py-5 border-b border-gray-200">
            <Image
              src={logo}
              alt="Uzbekistan Medi Logo"
              className="w-[130px] h-[45px] object-contain"
            />
            <IoMdClose
              className="text-3xl cursor-pointer"
              onClick={toggleMobileMenu}
              aria-label="Close menu"
            />
          </div>
          <nav className="flex flex-col gap-6 mt-6 px-4">
            {menuItems.map((item, index) => (
              <div key={index}>
                <Link
                  href={item.href}
                  className="flex items-center font-semibold gap-3 text-lg hover:bg-gray-200 transition duration-200 ease-in-out py-2 px-3 rounded"
                  onClick={(e) => {
                    if (!item.dropdown) {
                      setIsMobileMenuOpen(false);
                    } else {
                      e.preventDefault();
                      toggleMobileDropdown(index);
                    }
                  }}
                  aria-haspopup={item.dropdown ? "true" : undefined}
                  aria-expanded={
                    mobileActiveDropdown === index ? "true" : undefined
                  }
                >
                  {item.icon} {item.label}
                  {item.dropdown && (
                    <RiArrowDropDownLine
                      className={`text-black text-3xl transition-transform ${
                        mobileActiveDropdown === index
                          ? "rotate-180"
                          : "rotate-0"
                      }`}
                    />
                  )}
                </Link>
                {item.dropdown && mobileActiveDropdown === index && (
                  <ul className="pl-12 mt-2 space-y-3">
                    {item.dropdown.map((subItem, subIndex) => (
                      <li key={subIndex}>
                        <Link
                          href={subItem.href}
                          className="text-lg flex font-normal text-black hover:text-black transition duration-200 ease-in-out py-1.5"
                          onClick={() => {
                            setIsMobileMenuOpen(false);
                            setMobileActiveDropdown(null);
                          }}
                        >
                          {subItem.label}
                        </Link>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </nav>
        </div>
      </nav>
    </header>
  );
};

export default Navbar;
