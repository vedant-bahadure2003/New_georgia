import Link from "next/link";
import React from "react";
import Head from "next/head";
import { MdEmail } from "react-icons/md";
import { BiLocationPlus, BiPhone } from "react-icons/bi";

const Footer = () => {
  return (
    <>
      <Head>
        <meta
          name="description"
          content="Learn about Uzbekistan Medi, your trusted guide for pursuing MBBS in Uzbekistan. We offer support for top universities and globally recognized degrees."
        />
        <meta
          name="keywords"
          content="Uzbekistan Medi, MBBS in Uzbekistan, medical education, study in Uzbekistan, top universities, medical degrees"
        />
        <meta name="author" content="Uzbekistan Medi" />
      </Head>

      <div className="w-full h-auto bg-gradient-to-t from-[#005D61] to-[#038f96] flex items-center justify-center pb-3 flex-col gap-4  py-14">
        <div className="flex flex-col lg:flex-row gap-10 w-[90%] lg:w-[80%] h-auto text-black mt-[20px]">
          {/* About Section */}
          <div className="flex flex-col gap-4 lg:w-[40%]">
            <h2 className="text-[24px] lg:text-[24px] font-semibold text-white">
              About Uzbekistan Medi
            </h2>
            <p className="text-[12px] text-white">
              Uzbekistan Medi is your trusted partner in pursuing MBBS in
              Uzbekistan. With a mission to simplify medical education abroad,
              we connect aspiring doctors with top NMC and WHO-recognized
              universities.
            </p>
          </div>

          {/* Quick Links Section */}
          <div className="flex flex-col gap-4 lg:w-[40%] lg:items-center">
            <h2 className="text-[24px] lg:text-[24px] font-semibold text-white">
              Quick Links
            </h2>
            <div className="flex flex-col gap-3 text-[14px] text-white">
              <Link href={"#"}>Home</Link>
              <Link href={"/aboutus"}>About Us</Link>
              <Link href={"/contact-us"}>Contact Us</Link>
              <Link href={"/mbbs-in-uzbekistan"}>MBBS in Uzbekistan</Link>
            </div>
          </div>

          {/* Contact Us Section */}
          <div className="flex flex-col gap-3">
            <h2 className="text-[24px] lg:text-[24px] text-white font-semibold">
              Contact Us
            </h2>
            <div className="flex gap-2">
              <BiLocationPlus size={29} color="white" />
              <p className="text-[13px] text-white">
                KlickEdu, 1st Floor, MS Building, behind New Theatre, Aristo,
                Thampanoor, Thiruvananthapuram, Kerala, 695012.
              </p>
            </div>
            <div className="flex gap-2 text-white">
              <MdEmail size={20} color="white" />
              <p className="text-[13px]">info@klickedu.com</p>
            </div>
            <div className="flex gap-2 mt-1 text-white">
              <BiPhone size={20} color="white" />
              <p className="text-[13px]">8111 99 6000</p>
            </div>
          </div>
        </div>

        {/* Footer Bottom */}
        <div className="flex flex-col gap-2 w-[90%] lg:w-[80%]">
          <hr />
          <div className="flex text-[14px] py-2 text-white items-center justify-center">
            <p>
              © 2025 All Rights Reserved by Uzbekistan Medi, Parent Company of
              KlickEdu.
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default Footer;
