import Image from "next/image";
import React from "react";
import TrustPageimg from "../../../public/aboutus/Group 1707485468.svg";
import Tick from "../../../public/aboutus/charm_circle-tick.svg";

const TrustPage = () => {
  return (
    <>
      <div className="w-full pt-10">
        <div className="hidden md:block w-[90%] sm:w-[80%] mx-auto pb-8">
          <div className="flex justify-center items-center gap-5 flex-wrap">
            <div className="w-[494px] h-[494px] -mt-28 sm:-mt-0">
              <Image
                src={TrustPageimg}
                alt="TrustPage"
                className="w-full h-full object-contain"
              />
            </div>
            <div className="">
              <h2 className="font-semibold text-[24px]">
                Your Expert Guide to <br />
                <span className="text-[#16A8AF]">
                  MBBS Studies in Uzbekistan
                </span>
              </h2>
              <div className="flex items-center mt-7 gap-2">
                <Image src={Tick} alt="Tick" />
                <p className="text-[16px]">
                  Uzbekistan Medi is a sister company of KlickEdu.
                </p>
              </div>
              <div className="flex items-center mt-5 gap-2">
                <Image src={Tick} alt="Tick" />
                <p className="text-[16px]">
                  Helping you turn your dream of studying MBBS in Uzbekistan
                  into a reality.
                </p>
              </div>
              <div className="flex items-center mt-5 gap-2">
                <Image src={Tick} alt="Tick" />
                <p className="text-[16px]">
                  Providing accurate, up-to-date information about universities
                  and admissions.
                </p>
              </div>
              <div className="flex items-center mt-5 gap-2">
                <Image src={Tick} alt="Tick" />
                <p className="text-[16px]">
                  Connecting students with world-class medical education
                  opportunities.
                </p>
              </div>

              <button
                type="button"
                className="bg-[#16A8AF] mt-7 text-white py-2.5 px-6 rounded-lg text-[16px]"
              >
                Learn More Us
              </button>
            </div>
          </div>
        </div>

        {/* mobile view */}
        <div className="block md:hidden w-[90%] sm:w-[80%] mx-auto pb-8">
          <div className="flex justify-center items-center flex-wrap">
            <h2 className="font-semibold text-[24px] -mt-24 text-center">
              Your Expert Guide to
              <br />
              <span className="text-[#16A8AF]">MBBS Studies in Uzbekistan</span>
            </h2>
            <div className="w-[494px] h-[494px] sm:-mt-0 -mt-20">
              <Image
                src={TrustPageimg}
                alt="TrustPage"
                className="w-full h-full object-contain"
              />
            </div>
            <div className="-mt-12">
              <div className="flex items-center  gap-2">
                <Image src={Tick} alt="Tick" />
                <p className="text-[16px]">
                  Uzbekistan Medi is a sister company of KlickEdu.
                </p>
              </div>
              <div className="flex items-center mt-5 gap-2">
                <Image src={Tick} alt="Tick" />
                <p className="text-[16px]">
                  Helping you turn your dream of studying MBBS in Uzbekistan
                  into a reality.
                </p>
              </div>
              <div className="flex items-center mt-5 gap-2">
                <Image src={Tick} alt="Tick" />
                <p className="text-[16px]">
                  Providing accurate, up-to-date information about universities
                  and admissions.
                </p>
              </div>
              <div className="flex items-center mt-5 gap-2">
                <Image src={Tick} alt="Tick" />
                <p className="text-[16px]">
                  Connecting students with world-class medical education
                  opportunities.
                </p>
              </div>

              <button
                type="button"
                className="bg-[#16A8AF] mt-7 text-white py-2.5 px-6 rounded-lg text-[16px]"
              >
                Learn More Us
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default TrustPage;
