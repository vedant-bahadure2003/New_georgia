import Image from "next/image";
import React from "react";
import stars from "../../public/Images/groupstar.png";
import priyasharma from "../../public/Images/Priya_Sharma.jpg";
import rajesh from "../../public/Images/rajesh-gupta.jpg";
import aditi from "../../public/Images/aditi_verma.jpg";
// Dynamic data for testimonials
const testimonialsData = [
  {
    name: "Priya Sharma",
    course: "MBBS",
    testimonial:
      "Uzbekistan Medi guided me seamlessly through the entire process of studying MBBS in Uzbekistan. Their support made my dream a reality!",
    profileImage: priyasharma, // Correct image path
  },
  {
    name: "Rajesh Gupta",
    course: "BDS",
    testimonial:
      "Thanks to Uzbekistan Medi, I secured admission to a top medical university in Uzbekistan without any hassle. Highly recommended!",
    profileImage: rajesh, // Correct image path
  },
  {
    name: "Aditi Verma",
    course: "Pharmacy",
    testimonial:
      "Uzbekistan Medi’s guidance was excellent! From admissions to visas, they made everything easy. Excited to start my MBBS journey!",
    profileImage: aditi, // Correct image path
  },
];

const Testimonials = () => {
  return (
    <section
      className="w-[80%] mx-auto mt-[50px]"
      aria-labelledby="testimonials-title"
    >
      <header className="text-center">
        <h2
          id="testimonials-title"
          className="text-[24px] text-center font-[700]  sm:text-[36px] w-full"
        >
          Our Happy <span className="text-[#16A8AF] underline">Students</span>
        </h2>
        <p className="text-black text-[16px] lg:text-[18px] mt-2">
          Hear from our proud achievers.
        </p>
      </header>

      <div
        className="overflow-x-auto mt-10 scrollbar-hide"
        role="region"
        aria-label="Student Testimonials"
      >
        <div className="flex gap-6 items-center w-max">
          {testimonialsData.map((testimonial, index) => (
            <article
              key={index}
              className="bg-[#E9F7F8] w-[280px] h-[250px] md:w-[365px] md:h-[324px] relative rounded-tr-full rounded-br-full rounded-bl-full flex flex-col items-start justify-center p-5"
              aria-label={`Testimonial ${index + 1}`}
            >
              <blockquote className="text-gray-600  text-[14px] md:text-[18px] w-[80%]">
                {testimonial.testimonial}
              </blockquote>
              <div className="flex gap-1 my-8" aria-label="Star Rating">
                <Image
                  src={stars}
                  alt="5-star rating"
                  width={100}
                  height={20}
                />
              </div>
              <footer className="ml-14">
                <p className="font-semibold text-[14px] ">{testimonial.name}</p>
                <p className="text-gray-600 font-semibold">
                  {testimonial.course}
                </p>
              </footer>
              <Image
                src={testimonial.profileImage}
                alt={`${testimonial.name} smiling`}
                className="md:w-[164.98px]  md:h-[146.9px] w-[100px] h-[90px] object-cover absolute bottom-0 right-0 rounded-tl-full rounded-bl-full rounded-tr-full"
                width={100}
                height={90}
              />
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
