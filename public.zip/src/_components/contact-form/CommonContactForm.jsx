"use client";
import React from "react";
import Img from "../../../public/pana.svg";
import Image from "next/image";

const GetPersonalizedGuidanceForm = () => {
  return (
    <>
      <style jsx>{`
        .guidance-form-container {
          background-color: #b7fbff;
        }
      `}</style>

      <div className="guidance-form-container   py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto flex flex-col lg:flex-row lg:gap-x-5 items-center">
          {/* Left Section: Image */}
          <div className="lg:w-1/2 w-full">
            <Image
              src={Img}
              alt="Guidance illustration"
              className="w-[100%] h-full"
            />
          </div>

          {/* Right Section: Form */}
          <div className="lg:w-full w-full px-6 py-10">
            <h2 className="text-[24px] lg:text-[36px] font-bold mb-6 ">
              Get Personalized Guidance for Your MBBS Journey
            </h2>
            <form className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
              <input
                className="border rounded-md w-full py-2.5 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id="name"
                type="text"
                placeholder="Enter your name"
              />

              <input
                className="border rounded-md w-full py-2.5 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id="email"
                type="email"
                placeholder="Enter your email"
              />

              <input
                className="border rounded-md w-full py-2.5 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id="mobile"
                type="text"
                placeholder="Enter your mobile number"
              />

              <input
                className="border rounded-md w-full py-2.5 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                id="city"
                type="text"
                placeholder="Enter your current city"
              />
            </form>
            <div className="mt-5 text-center w-full">
              <button
                className="bg-[#0da9b0] hover:bg-[#0da9b0] text-white text-[16px] font-semibold py-2 px-10 rounded-lg focus:outline-none focus:shadow-outline"
                type="button"
              >
                Apply Now
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default GetPersonalizedGuidanceForm;
