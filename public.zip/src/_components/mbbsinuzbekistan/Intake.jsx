import React from "react";

const Intake = () => {
  const intakeData = {
    title: "MBBS in Uzbekistan - Intake Date & Deadlines 2025",
    description:
      "The MBBS intake in Uzbekistan generally takes place in September. Students should apply between June and July. Visa processing takes 4 to 6 weeks, so it's recommended to start the process 2 to 3 months before the session begins.",
    details: [
      { event: "Intake", value: "September" },
      { event: "Semester Duration", value: "Approximately 6 months each" },
      { event: "Application Date", value: "June to July" },
      { event: "Visa Processing Time", value: "4 to 6 weeks" },
      {
        event: "Recommended Visa Application",
        value: "2 to 3 months before session starts",
      },
    ],
  };

  return (
    <>
      {/* Desktop View */}
      <div className="hidden lg:flex lg:w-[95%] lg:mx-auto flex-col gap-3 py-6">
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#16A8AF]">
          {intakeData.title}
        </h2>
        <p className="text-[14px] sm:text-[16px] font-[550]">
          {intakeData.description}
        </p>
        <table className="w-full text-[14px] sm:text-[16px] text-left border border-black">
          <tbody>
            <tr className="bg-gray-200 border">
              <td className="px-4 py-2 border border-black font-bold text-center">
                Event
              </td>
              <td className="px-4 py-2 border border-black font-bold text-center">
                Details
              </td>
            </tr>
            {intakeData.details.map((item, index) => (
              <tr key={index} className="odd:bg-[#FFF7EE] even:bg-white">
                <td className="px-4 py-2 border border-black">{item.event}</td>
                <td className="px-4 py-2 border border-black">{item.value}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile View */}
      <div className="lg:hidden px-4 py-4">
        <h2 className="text-[22px] font-[700] text-[#16A8AF]">
          {intakeData.title}
        </h2>
        <p className="text-[14px] font-semibold">{intakeData.description}</p>
        <table className="w-full text-xs text-left border border-black mt-3">
          <tbody>
            <tr className="bg-gray-200 border">
              <td className="px-2 py-1 border border-black font-semibold">
                Event
              </td>
              <td className="px-2 py-1 border border-black font-semibold">
                Details
              </td>
            </tr>
            {intakeData.details.map((item, index) => (
              <tr key={index} className="odd:bg-[#FFF7EE] even:bg-white">
                <td className="px-2 py-1 border border-black">{item.event}</td>
                <td className="px-2 py-1 border border-black">{item.value}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default Intake;
