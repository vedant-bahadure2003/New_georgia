import React from "react";
import YtFrame from "./YtFrame";

const Highlight = () => {
  const data = [
    {
      title: "Key Information",
      value: "Details",
      titleClass: "font-semibold text-center",
      valueClass: "font-semibold text-center ",
    },
    {
      title: "Intake for MBBS Course",
      value: "September-Octomber (Every Year)",
    },
    {
      title: "Eligibility Criteria for MBBS",
      value:
        "12th standard with a minimum of 50% in the PCB group; Minimum age: 17 years",
    },
    {
      title: "NEET Examination",
      value: "Mandatory (should be qualified)",
    },
    {
      title: "Duration of MBBS Course",
      value: "6 years (5 years of academics + 1-year internship)",
    },
    {
      title: "Medium of Teaching",
      value: "English language",
    },
    {
      title: "Number of NMC-approved Universities",
      value: "6",
    },
    {
      title: "Recognitions",
      value: "NMC, WHO, WDOMS, FAIMER, ECFMG",
    },
    {
      title: "Minimum Tuition Fees",
      value: "$3,400 per year",
    },
    {
      title: "Maximum Tuition Fees",
      value: "$4,200 per year",
    },
    {
      title: "Top Medical Universities",
      value:
        "Andijan State Medical Institute, Samarkand State Medical University",
    },
    {
      title: "Cost of Living",
      value: "Approximately $150 per month",
    },
    {
      title: "Admission Processing Time",
      value: "45-60 days",
    },
  ];

  return (
    <>
      <div id="HighLight" className="mt-5 p-5 ">
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#16A8AF]">
          MBBS in Uzbekistan - Quick Highlights 2025
        </h2>
        <p className="text-[14px] sm:text-[16px] font-[550] ">
          Keep the following key points in mind when applying for admission to
          MBBS programs in Uzbekistan’s medical colleges:
        </p>

        {/* Table Section */}
        <div className="overflow-x-auto mt-5">
          <table className="w-full text-sm text-left rtl:text-right border border-black">
            <tbody>
              {data.map((item, index) => (
                <tr
                  key={index}
                  className="odd:bg-[#FFF7EE] even:bg-white border"
                >
                  <td
                    className={`text-[14px] sm:text-[16px] px-4 py-2 border border-black ${item.titleClass}`}
                  >
                    {item.title}
                  </td>
                  <td
                    id="whystudy"
                    className={`text-[14px] sm:text-[16px]  px-4 py-2 border border-black ${item.valueClass}`}
                  >
                    {item.value}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* YouTube Frame Section */}
        {/* <YtFrame /> */}
      </div>
    </>
  );
};

export default Highlight;
