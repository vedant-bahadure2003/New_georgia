import React from "react";

const CourseOffered = () => {
  // Dynamic data for courses offered
  const courses = [
    {
      name: "MBBS (Bachelor of Medicine, Bachelor of Surgery)",
      duration: "6 Years (5 years + 1-year Internship)",
    },
    { name: "BDS (Bachelor of Dental Surgery)", duration: "5 Years" },
    {
      name: "MD (Doctor of Medicine)",
      duration: "3 - 4 Years (depending on specialisation)s",
    },
    { name: "MDS (Master of Dental Surgery)", duration: "3 - 4 Years" },
    { name: "Pharmacy", duration: "4 Years" },
    { name: "Nursing", duration: "4 Years" },
    { name: "Physiotherapy", duration: "4 Years" },
    { name: "Public Health", duration: "2 - 3 Years" },
  ];

  return (
    <>
      <div className="px-4 lg:w-[95%] lg:mx-auto md:px-0">
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#16A8AF]  md:text-left">
          Courses offered by Uzbekistan Medical Universities
        </h2>
        <p className="text-[14px] sm:text-[16px] font-[550] mt-2 my-3  md:text-left">
          Uzbekistan's medical universities offer a variety of courses,
          including MBBS, BDS, MD, and more, catering to diverse medical fields.
          These programs provide students with both theoretical knowledge and
          practical experience in healthcare:
        </p>

        {/* Dynamic Courses Table */}
        <table className="w-full text-[14px] sm:text-[16px] text-left rtl:text-right border border-black mt-5">
          <thead>
            <tr className="odd:bg-[#FFF7EE] even:bg-white border">
              <th className="px-4 py-2 border border-black  text-black text-center">
                Course Name
              </th>
              <th className="px-4 py-2 border border-black text-black text-center">
                Duration
              </th>
            </tr>
          </thead>
          <tbody>
            {/* Map through the courses data */}
            {courses.map((course, index) => (
              <tr
                key={index}
                className={`odd:bg-white even:bg-[#FFF7EE] ${
                  index % 2 === 0 ? "bg-[#FFF7EE]" : "bg-white"
                }`}
              >
                <td className="px-4 py-2 border border-black">{course.name}</td>
                <td className="px-4 py-2 border border-black">
                  {course.duration}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default CourseOffered;
