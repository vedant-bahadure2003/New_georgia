import Image from "next/image";
import React from "react";
import rightsign from "../../../public/Images/vector.png";
import PassingPercentage from "./PassingPercentage";
const Syllabus = () => {
  // Dynamic data for the syllabus
  const syllabusData = [
    {
      year: "First Year",
      subjects: [
        "Bioorganic Chemistry, Cytology, Human Anatomy, General Psychology, Internal Medicine",
      ],
    },
    {
      year: "Second Year",
      subjects: [
        "Microbiology, Histology, Physiology, Patient Care, Biochemistry, Anatomy, Psychology",
      ],
    },
    {
      year: "Third Year",
      subjects: [
        "ENT, Forensic Medicine, Embryology, Radiology, Medical Chemistry",
      ],
    },
    {
      year: "Fourth Year",
      subjects: ["Surgery, Community Medicine, Pharmacology, Allied Subjects"],
    },
    {
      year: "Fifth Year",
      subjects: ["Ophthalmology, Infectious Disease, Gynecology & Obstetrics"],
    },
    {
      year: "Sixth Year",
      subjects: [
        "Internship at a university-affiliated hospital under the supervision of a trained professional",
      ],
    },
  ];

  return (
    <>
      <div className=" sm:rounded-lg p-4 mt-4">
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#16A8AF] sm:text-left">
          MBBS Syllabus in Uzbekistan (Yearwise)
        </h2>
        <p className="text-[14px] sm:text-[16px] font-[550]">
          The MBBS program in Uzbekistan lasts 6 years, with the final year
          dedicated to clinical training and internships. Here's a breakdown of
          subjects by year.
        </p>

        {/* Dynamic Syllabus Table */}
        <table className="w-full bg-[#FFF7EE] text-sm sm:text-base text-left rtl:text-right border border-black mt-5">
          <thead>
            <tr>
              <th className="px-4 py-2 border text-[14px] sm:text-[16px] font-semibold border-black text-center">
                Year
              </th>
              <th className="px-4 py-2 border text-[14px] sm:text-[16px] font-semibold border-black text-center">
                Subjects
              </th>
            </tr>
          </thead>
          <tbody>
            {syllabusData.map((item, index) => (
              <tr key={index} className="odd:bg-white even:bg-[#FFF7EE]">
                <td className="text-[14px] sm:text-[16px] px-4 py-2 border border-black">
                  {item.year}
                </td>
                <td className="text-[14px] sm:text-[16px] px-4 py-2 border border-black">
                  <ul className=" list-inside">
                    {item.subjects.map((subject, subIndex) => (
                      <li key={subIndex}>{subject}</li>
                    ))}
                  </ul>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Total Duration of MBBS */}
        <div className=" flex flex-col gap-5 mt-[30px] p-1">
          <div className="flex flex-col justify-center items-start gap-2">
            <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0] sm:text-left">
              Total Duration of MBBS in Uzbekistan
            </h2>
            <p className="text-[14px] sm:text-[16px] font-[550] sm:text-left">
              The total duration of the MBBS course at Uzbekistan Medical
              University is six years. The course can be divided into:
            </p>
          </div>

          {/* Dynamic Duration List */}
          <div className="text-[14px] sm:text-[16px] flex flex-col gap-2">
            {[
              "Five Years of Theoretical Studies: The first five years are spent learning various subjects, including Anatomy, Phtopysiology, Biochemistry, and all other medical disciplines.",
              "One Year of Internship: The final year is dedicated to practical training in the form of internships. Students work in hospitals or clinics, applying their theoretical knowledge in real-world settings under the supervision of trained professionals.",
            ].map((durationItem, index) => (
              <div className="flex gap-2" key={index}>
                <Image
                  src={rightsign}
                  alt="vector"
                  className="text-[16px] h-[18px] w-[18px] mt-1"
                />
                <p className="text-[14px] sm:text-[16px] flex gap-2">
                  {durationItem}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div>
        <PassingPercentage />
      </div>
    </>
  );
};

export default Syllabus;
