import React from "react";

const AdmissionProcess = () => {
  const admissionSteps = [
    {
      step: 1,
      description: "Visit the university portal to submit your application.",
    },
    {
      step: 2,
      description:
        "Make scans of all the documents and send them to the university.",
    },
    {
      step: 3,
      description:
        "You are supposed to get an invitation letter in not more than 48 hours.",
    },
    {
      step: 4,
      description: "Complete the registration payment.",
    },
    {
      step: 5,
      description: "Now, apply for a student visa.",
    },
    {
      step: 6,
      description: "The visa processing typically takes two weeks.",
    },
    {
      step: 7,
      description: "Notify the university of your arrival date.",
    },
    {
      step: 8,
      description: "Travel to Uzbekistan and start your studies.",
    },
  ];

  return (
    <div className=" p-3">
      <div className="gap-2">
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]">
          Admission Process for MBBS in Uzbekistan
        </h2>
        <p className=" text-[14px] sm:text-[16px] font-[550]">
          The process to apply for MBBS in Uzbekistan is simple. Just follow
          these easy steps to enroll in the course.
        </p>
      </div>
      <div className="mt-5 ">
        <div className="text-[14px] sm:text-[16px] flex flex-col gap-4 text-black">
          {admissionSteps.map((stepItem, index) => (
            <div key={index} className="flex  ">
              <p className="w-[60px] text-[#0da9b0] font-[700] text-[14px] sm:text-[16px] ">
                Step {stepItem.step}:
              </p>
              <p className="  flex-1 text-[14px] sm:text-[16px]">
                {stepItem.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdmissionProcess;
