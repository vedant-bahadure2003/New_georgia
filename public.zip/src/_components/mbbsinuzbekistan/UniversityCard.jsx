import Link from "next/link";
import Image from "next/image";
import React from "react";
import Andijan from "../../../public/UniversityLogo/Andijan State Medical Institute.webp";
import Bukhara from "../../../public/UniversityLogo/Bukhara State Medical InstituTE.webp";
import Fergana from "../../../public/UniversityLogo/Fergana Medical Institute.webp";
import Samarkand from "../../../public/UniversityLogo/samarkand State.webp";
import Tashkent from "../../../public/UniversityLogo/Tashkent Medical Academy.webp";
import TashkentDental from "../../../public/UniversityLogo/Tashkent State Dental Institute.webp";

const UniversityCard = ({ number, university }) => {
  return (
    <div
      className="rounded-lg overflow-hidden mt-5 p-5 flex flex-col gap-4"
      style={{
        boxShadow:
          "0px 4px 5px rgba(156, 163, 175, 0.6), 0px -0px 5px rgba(156, 163, 175, 0.6)",
      }}
    >
      {/* Title */}
      <h3 className="text-[16px] sm:text-[16px] font-semibold text-center md:text-left">
        {number}. {university.name}
      </h3>

      {/* Image and Content Section */}
      <div className="flex flex-col md:flex-row gap-4">
        {/* College Logo */}
        <div className="flex justify-center md:justify-start">
          <div className="h-[150px] w-[150px] md:h-[174px] md:w-[174px] relative">
            <Image
              src={university.logo} // Now using the correct logo
              alt={university.name.toLowerCase()}
              className="object-contain rounded-lg"
              fill
            />
          </div>
        </div>

        {/* Content */}
        <div className="flex flex-col">
          <ul className="text-[14px] sm:text-[16px] list-disc p-3 space-y-1">
            {university.details.map((detail, index) => (
              <li key={index}>{detail}</li>
            ))}
          </ul>
        </div>
      </div>

      {/* Table Section */}
      <div className="overflow-x-auto">
        <table className="w-full text-[14px] sm:text-[16px] text-left border border-black">
          <tbody>
            {university.info.map((row, index) => (
              <tr
                key={index}
                className={`${
                  index % 2 === 0 ? "odd:bg-[#FFF7EE]" : "even:bg-white"
                } border`}
              >
                <td className="text-[14px] sm:text-[16px] px-4 py-2 border border-black font-medium">
                  {row.label}
                </td>
                <td className="text-[14px] sm:text-[16px] px-4 py-2 border border-black">
                  {row.value}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Buttons */}
      <div className="flex flex-col justify-end sm:flex-row gap-3 mt-2">
        <button className="bg-[#16A8AF] w-full sm:w-[132px] h-[40px] rounded-lg text-white text-sm md:text-lg">
          Apply Now
        </button>
        <Link href={university.link}>
          <button className="border border-black w-full sm:w-[132px] h-[40px] rounded-lg text-base">
            Read More
          </button>
        </Link>
      </div>
    </div>
  );
};

const UniversityList = () => {
  const universities = [
    {
      name: "Andijan State Medical Institute",
      logo: Andijan,
      details: [
        "Established in 1955, it is known for its high-quality medical education.",
        "Recognized by NMC, WHO, AMEE, EMSA, and FAIMER, it offers a 5+1 year MBBS program in English.",
        "The institute has over 56 departments and attracts students worldwide.",
      ],
      link: "/andijan-state-medical-university",
      info: [
        { label: "Established Year", value: "1955" },
        { label: "Course Duration", value: "5+1 Years" },
        { label: "Eligibility Criteria", value: "10+2 with 50% marks, NEET" },
        { label: "Language of Study", value: "English" },
        { label: "Last Date to Apply", value: "1st Aug, 2025" },
      ],
    },
    {
      name: "Samarkand State Medical Institute",
      logo: Samarkand,
      details: [
        "Founded in 1930, Samarkand State Medical Institute is renowned for its extensive facilities.",
        "Recognized by NMC, WHO, AMEE, EMSA, and FAIMER, it offers a 5+1 year MBBS program in English.",
      ],
      link: "/samarkand-state-medical-university",
      info: [
        { label: "Established Year", value: "1930" },
        { label: "Course Duration", value: "5+1 Years" },
        { label: "Eligibility Criteria", value: "10+2 with 50% marks, NEET" },
        { label: "Language of Study", value: "English" },
        { label: "Last Date to Apply", value: "1st Aug, 2025" },
      ],
    },
    {
      name: "Tashkent Medical Academy",
      logo: Tashkent,
      details: [
        "Tashkent Medical Academy, founded in 2005, is one of the leading medical institutions in Uzbekistan.",
        "Recognized by NMC, WHO, AMEE, EMSA, and FAIMER, it offers a 5+1 year MBBS program in English.",
        "The academy is known for its world-class infrastructure and dedicated faculty.",
      ],
      link: "/tashkent-medical-academy",
      info: [
        { label: "Established Year", value: "2005" },
        { label: "Course Duration", value: "5+1 Years" },
        { label: "Eligibility Criteria", value: "10+2 with 50% marks, NEET" },
        { label: "MBBS Fee", value: "18000 $ / Rs. 12,40,000 (Approx.)" },
        { label: "Language of Study", value: "English" },
        { label: "Last Date to Apply", value: "1st Aug, 2025" },
      ],
    },
    {
      name: "Fergana Medical Institute of Public Health",
      logo: Fergana,
      details: [
        "Founded in 1991, Fergana Medical Institute is a top choice for international students.",
        "Recognized by NMC, WHO, AMEE, EMSA, and FAIMER, it offers a 5+1 year MBBS program in English.",
      ],
      link: "/fergana-medical-institute",
      info: [
        { label: "Established Year", value: "1991" },
        { label: "Course Duration", value: "5+1 Years" },
        { label: "Eligibility Criteria", value: "10+2 with 50% marks, NEET" },
        { label: "Language of Study", value: "English" },
        { label: "Last Date to Apply", value: "1st Aug, 2025" },
      ],
    },

    {
      name: "Bukhara State Medical Institute",
      logo: Bukhara,
      details: [
        "Bukhara State Medical Institute, established in 1990, is a well-established university offering a comprehensive MBBS program in English. ",
        "With recognition from NMC, WHO, AMEE, EMSA, and FAIMER, it provides a solid foundation in medical sciences.",
        " The university is excellent for international students seeking a quality medical education.",
      ],
      link: "/bukhara-state-medical-institute",
      info: [
        { label: "Established Year", value: "1990" },
        { label: "Course Duration", value: "5+1 Years" },
        { label: "Eligibility Criteria", value: "10+2 with 50% marks, NEET" },
        { label: "Language of Study", value: "English" },
        { label: "Last Date to Apply", value: "1st Aug, 2025" },
      ],
    },
    {
      name: "Tashkent State Dental Institute",
      logo: TashkentDental,
      details: [
        "Established in 2014, Tashkent State Dental Institute is known for its rapid growth and high-quality medical education.",
        "Recognized by NMC and WHO, the institute offers a 6-year MBBS program in English, including a 1-year internship.",
        "It has a modern infrastructure with state-of-the-art classrooms, an air-conditioned auditorium, and a well-stocked library. ",
      ],
      link: "/tashkent-state-dental-institute",
      info: [
        { label: "Established Year", value: "2014" },
        { label: "Course Duration", value: "6 Years (with 1-year internship)" },
        {
          label: "Eligibility Criteria",
          value: "50% in Physics, Chemistry, and Biology Aggregate, NEET",
        },
        { label: "Language of Study", value: "English" },
        { label: "Last Date to Apply", value: "1st Aug, 2025" },
      ],
    },
  ];

  return (
    <div>
      {universities.map((university, index) => (
        <UniversityCard
          key={index}
          number={index + 1}
          university={university}
        />
      ))}
    </div>
  );
};

export default UniversityList;
