import React from "react";
import Image from "next/image";
import rightsign from "../../../public/Images/vector.png";

const Whystudy = () => {
  const reasons = [
    {
      text: "Tuition fees are lower compared to private medical colleges in India.",
    },
    {
      text: "NMC, WHO, and other global bodies recognised universities.",
    },
    {
      text: "English is the medium of instruction, ensuring ease for Indian students.",
    },
    {
      text: "High-quality education with advanced teaching methods and modern facilities.",
    },
    {
      text: "Small class sizes provide better attention to students’ academic needs.",
    },
    {
      text: "Supportive faculty and a student-friendly environment make adoption easier.",
    },
    {
      text: "Universities have excellent infrastructure and affordable living costs.",
    },
  ];

  return (
    <>
      {/* why study in Uzbekistan */}
      <div id="fees" className="mt-10 p-5">
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]">
          Why Study MBBS in Uzbekistan for Indian Students?
        </h2>
        <div className="text-lg sm:text-[18px] flex flex-col gap-2 ">
          <div className=" flex flex-col gap-3 text-gray-800">
            <p className="font-[550] text-[14px] sm:text-[16px]">
              MBBS in Uzbekistan has recently become the first choice for Indian
              students because not only is it very affordable and high-quality,
              but it also offers globally recognised degrees. Here it is the
              most important reasons why Uzbekistan medical universities are a
              popular choice:
            </p>
            {reasons.map((reason, index) => (
              <div key={index} className="flex gap-2">
                <Image
                  src={rightsign}
                  alt="vector"
                  className="h-[18px] w-[18px] mt-1"
                />
                <p className="flex text-[14px] sm:text-[16px] gap-2 text-black text-justify">
                  {reason.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Whystudy;
