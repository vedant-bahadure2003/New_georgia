"use client";

import React, { useState } from "react";
import Image from "next/image";
import Profile from "../../../public/Images/profile.png";
// import TableContent from "./TableContent";
import greentick from "../../../public/Images/greentick.png";
import Link from "next/link";

const Xyz = () => {
  return (
    <>
      {/* Content */}
      <div className="w-full ">
        {/* Main content container */}
        <div className="flex w-full  items-center mt-[3rem] px-1 sm:px-2 lg:px-0">
          <div className="h-fit w-full flex flex-col bg-white rounded-md ">
            {/* Profile section */}
            <div className="flex gap-3 w-full h-[3.125rem] items-center px-4 sm:px-6">
              <div className="w-[3.125rem] h-[3.125rem]">
                <Image
                  src={Profile}
                  alt="profile"
                  className="w-full h-full object-cover rounded-full"
                />
              </div>

              <div className="text-[14px] lg:text-[16px] font-[450]">
                <h2>
                  <Link href="https://www.linkedin.com/in/vedant-bahadure-269893250?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app">
                    <span className="text-blue-600 font-[550] ">
                      Vedant Bahadure, <br />{" "}
                    </span>{" "}
                  </Link>{" "}
                  MBBS Abroad Expert{" "}
                </h2>
              </div>

              <div>
                <Image
                  src={greentick}
                  alt="greentick"
                  className="w-[23px] h-[23px]"
                />
              </div>
            </div>

            {/* Text section */}
            <div className="text-justify   w-full leading-5 py-3 px-4 sm:px-6 relative">
              <p className="text-black text-[14px] sm:text-[16px] ">
                <span className="font-bold"> MBBS in Uzbekistan</span> is an
                ideal choice for international students due to its affordability
                and excellent quality of education. The MBBS course duration is
                6 years, which includes 5 years of classroom-based theoretical
                and practical learning at top medical universities and 1 year of
                clinical training or internship. <br /> <br /> The total cost of
                pursuing MBBS in Uzbekistan for Indian students in 2025 ranges
                from INR 15 - 23 lacs, covering tuition fees, hostel
                accommodation, medical expenses, and miscellaneous costs. The
                cost of living is also budget-friendly, ranging from $850 - $950
                per month, including accommodation. <br /> <br /> The MBBS
                course in Uzbekistan is taught in English, making it accessible
                for international students. Over 4,000 Indian students choose
                Uzbekistan annually due to its modern medical universities and
                multidisciplinary hospitals equipped with advanced healthcare
                facilities. <br /> <br /> Top Medical universities offering MBBS
                programs include Andijan State Medical Institute, Samarkand
                State Medical University, and Bukhara State Medical Institute.{" "}
                <br /> <br />
                These universities are accredited by international bodies like
                WHO, NMC, and FAIMER, enabling graduates to apply for medical
                licensure worldwide. Admissions begin in July, and classes
                commence in September. Eligibility requirements include a NEET
                qualification and a minimum of 50% in Physics, Chemistry, and
                Biology in high school. With globally recognised medical
                education, a strong focus on practical training, and low living
                costs, Uzbekistan is emerging as a top destination for MBBS
                aspirants worldwide. <br />
                <br />
                With globally recognised medical education, a strong focus on
                practical training, and low living costs, Uzbekistan is emerging
                as a top destination for MBBS aspirants worldwide.
              </p>
            </div>
          </div>
        </div>
        {/* <div className="p-5">
          <TableContent />
        </div> */}
      </div>
    </>
  );
};

export default Xyz;
