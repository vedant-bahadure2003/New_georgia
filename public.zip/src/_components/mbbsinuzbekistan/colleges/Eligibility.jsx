import React from "react";
import Image from "next/image";
import vector from "../../../../public/Images/vector.png";

// Eligibility criteria data
const eligibilityCriteria = [
  "Age - The student applying must be not less than 17 years old by December 31 of the admission year.",
  "Indian students must pass the NEET exam to seek admission to foreign medical colleges.",
  "The validity of the NEET score is three years from the date of declaration of the result.",
];

const Eligibility = () => {
  return (
    <div className="flex flex-col  py-6  lg:py-10 p-2">
      {/* Title */}
      <h2 className="text-[22px] lg:text-[28px] font-bold text-[#0da9b0]">
        Eligibility Criteria to Study MBBS at Andijan State Medical Institute
      </h2>
      <p className="text-[14px] sm:text-[16px] font-[550]">
        The applicant must have a minimum of 70% in Physics, Chemistry, and
        Biology from any recognised board.
      </p>

      {/* Eligibility List */}
      <div className="text-[14px] sm:text-[16px] ml-3 py-4 bg-[#FFF9EA] flex flex-col gap-4">
        {eligibilityCriteria.map((point, index) => (
          <div key={index} className="flex gap-3">
            <Image
              src={vector}
              alt="vector"
              className="h-[16px] w-[16px] sm:h-[18px] sm:w-[18px] mt-1"
            />
            <p className="text-justify text-[14px] sm:text-[16px]">{point}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Eligibility;
