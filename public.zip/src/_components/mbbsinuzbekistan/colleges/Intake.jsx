import React from "react";
import vector from "../../../../public/Images/vector.png";
import Image from "next/image";

const Intake = () => {
  return (
    <>
      {/* MBBS Fees in Uzbekistan Section */}
      <div
        id="Intake"
        className=" lg:w-[95%] ml-3 lg:mx-auto flex flex-col gap-2 mt-[30px] p-1"
      >
        <div className="flex flex-col justify-center items-start gap-2">
          <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]">
            MBBS Fees in Uzbekistan
          </h2>
          <p className="text-[14px] sm:text-[16px] font-semibold">
            To get admission to the MBBS course in Uzbekistan, students need to
            follow the simple steps:
          </p>
        </div>
        <div className="text-[14px] sm:text-[16px] flex flex-col  ">
          <div className="text-[14px] sm:text-[16px] flex flex-col ">
            <div className="flex gap-2">
              <p className="flex gap-2 text-[14px] sm:text-[16px]">
                Eligible students need to check the postgraduate options after
                acquiring the MBBS degree in Uzbekistan. After receiving an MBBS
                degree from Uzbekistan University, Indian college students can
                review the eligibility standards for pursuing postgraduate
                research in India in addition to abroad.
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className=" hidden lg:flex lg:w-[95%] lg:mx-auto   flex-col gap-3 py-6">
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]">
          Andijan State Medical Institute - Intake Dates & Deadlines 2025
        </h2>
        <p className="text-[14px] sm:text-[16px] font-semibold">
          The total duration for the MBBS course in Uzbekistan is mentioned
          below:
        </p>
        <table className="w-full text-[14px] sm:text-[16px] text-left rtl:text-right border border-black">
          <tbody>
            <tr className="odd:bg-[#FFF7EE] even:bg-white border">
              <td className="px-4 py-2 border border-black font-medium">
                Events
              </td>
              <td className="px-4 py-2 border border-black">Second Year</td>
            </tr>
            <tr className="odd:bg-[#FFF7EE] even:bg-white">
              <td className="px-4 py-2 border border-black">
                Commencement of 2024 intake cycle
              </td>
              <td className="px-4 py-2 border border-black">September 2025</td>
            </tr>
            <tr className="odd:bg-[#FFF7EE] even:bg-white">
              <td className="px-4 py-2 border border-black">
                Commencement of Application
              </td>
              <td className="px-4 py-2 border border-black">September 2025</td>
            </tr>
            <tr className="odd:bg-[#FFF7EE] even:bg-white">
              <td className="px-4 py-2 border border-black">Admission Later</td>
              <td className="px-4 py-2 border border-black">
                within the next 3-4 weeks
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Mobile View */}
      <div className="lg:hidden lg:w-[95%] lg:mx-auto  ">
        <div className="flex flex-col gap-3 py-4 px-4">
          <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#16A8AF]">
            Andijan State Medical Institute - Intake Dates & Deadlines 2025
          </h2>
          <p className="text-[14px] sm:text-[16px] font-semibold">
            The admission dates for the 2025 - 2026 intake cycle at Andijan
            State Medical University are as follows:
          </p>
          <table className="w-full text-[14px] sm:text-[16px] text-left rtl:text-right border border-black">
            <tbody>
              <tr className="odd:bg-[#FFF7EE] even:bg-white border">
                <td className="px-2 py-1 border border-black font-medium">
                  Commencement of 2025 intake cycle
                </td>
                <td className="px-2 py-1 border border-black">
                  September 2025
                </td>
              </tr>
              <tr className="odd:bg-[#FFF7EE] even:bg-white">
                <td className="px-2 py-1 border border-black">
                  Commencement of Application
                </td>
                <td className="px-2 py-1 border border-black">
                  September 2025
                </td>
              </tr>
              <tr className="odd:bg-[#FFF7EE] even:bg-white">
                <td className="px-2 py-1 border border-black">
                  Admission Letter
                </td>
                <td className="px-2 py-1 border border-black">
                  within the next 3-4 weeks
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="  lg:flex lg:w-[95%] lg:mx-auto   flex-col gap-3 ml-3 py-6">
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#16A8AF]">
          Andijan State Medical Institute Ranking{" "}
        </h2>
        <p className="text-[14px] sm:text-[16px] font-semibold">
          According to 4icu.org, following is the country and world ranking for
          Andijan State Medical Institute:
        </p>
        <table className="w-full text-[14px] sm:text-[16px] text-left rtl:text-right border border-black">
          <tbody>
            <tr className="odd:bg-[#FFF7EE] even:bg-white border">
              <td className="px-4 py-2 border border-black font-medium">
                Country
              </td>
              <td className="px-4 py-2 border border-black">World</td>
            </tr>
            <tr className="odd:bg-[#FFF7EE] even:bg-white border">
              <td className="px-4 py-2 border border-black font-medium">44</td>
              <td className="px-4 py-2 border border-black">9625</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Medium of teaching */}
      <div
        id="Intake"
        className=" lg:w-[95%] ml-3 lg:mx-auto flex flex-col gap-2 mt-[30px] p-1"
      >
        <div className="flex flex-col justify-center items-start gap-2">
          <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]">
            Medium of Teaching in Andijan State Medical Institute
          </h2>
        </div>
        <div className="text-[14px] sm:text-[16px] flex flex-col  ">
          <div className="text-[14px] sm:text-[16px] flex flex-col ">
            <div className="flex gap-2">
              <p className="flex gap-2 text-[14px] sm:text-[16px]">
                Andijan State Medical Institute's MBBS program is conducted in
                English, making it very popular among Indian and international
                students. Since the instruction language is English, students
                will have better comprehension and a more significant influx of
                students from different parts of the globe.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Infrastructure and facilities */}
      <div className="flex flex-col lg:w-[95%] lg:mx-auto lg:flex-row lg:justify-start items-center lg:items-start lg:mt-20 ml-3">
        <div className=" flex flex-col py-6 bg-white">
          {/* Title */}
          <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]  ">
            Infrastructure & Facilities at ASMI
          </h2>

          {/* Description */}
          <p className="text-justify font-semibold text-[14px] sm:text-[16px] pr-4 sm:pr-8 mt-3 sm:mt-4">
            The Andijan State Medical Institute offers a unique student home on
            campus with all essential facilities for a comfortable stay. This
            well-designed university provides everything needed to support
            students academically and personally, ensuring a balanced and
            enjoyable campus life.
          </p>

          {/* Content Section */}
          <div className="text-[14px] sm:text-[16px] py-3 flex flex-col gap-3 sm:gap-4 mt-4 sm:mt-6 pr-4 sm:pr-8">
            {[
              "A reading room containing 1220 books, 23 newspapers, and 16 magazines.",
              "Seating for 76 people.",
              "An internet facility with modern computers for continuous use.",
              "An educational and relaxation area, along with a living room featuring a TV and DVD player.",
              "A fully equipped gym for fitness activities.",
              "A utility building with a photo studio, barbershop, and sewing services.",
            ].map((text, index) => (
              <div
                id="accrediation"
                key={index}
                className="flex items-start gap-2"
              >
                <Image
                  src={vector}
                  alt="vector"
                  className="h-[16px] w-[16px] sm:h-[18px] sm:w-[18px] mt-1"
                />
                <p className="text-justify text-[14px] sm:text-[16px]">
                  {text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Intake;
