"use client";
import React, { useState } from "react";
import { useAutoAnimate } from "@formkit/auto-animate/react";
import Image from "next/image";
import Minus from "../../../../public/Images/minus.png";
import Plus from "../../../../public/Images/plus.png";

// FAQ Data
const faqs = [
  {
    question:
      "Do I need to take any entrance exam to be admitted into Andijan State Medical Institute??",
    answer:
      "To get admission into Andijan State Medical Institute, international students must clear the NEET exam, a requirement to enrol in the university's medical courses.",
  },
  {
    question:
      "Does Andijan State Medical Institute offer postgraduate courses?",
    answer:
      "Yes, Andijan State Medical Institute offers postgraduate specialisation courses in various fields such as Anatomy, Dermatology, Pharmacology, Obstetrics and Gynecology, Cardiology, and many others for students who have completed their MBBS in Uzbekistan.",
  },
  {
    question:
      "Is the degree from Andijan State Medical Institute recognised in India?",
    answer:
      "Yes, the degree awarded by Andijan State Medical Institute is recognised in India. The institute is approved by the NMC, and graduates can practice medicine in India after clearing the FMGE/NEXT examination.",
  },
  {
    question: "Is Indian food available at Andijan State Medical Institute?",
    answer:
      "Yes, Indian food is available. The institute provides facilities such as a common kitchen and food options tailored for Indian students, ensuring they have access to familiar meals",
  },
  {
    question: "What are the fees for MBBS at Andijan State Medical Institute?",
    answer:
      "The total fees for the 6-year MBBS program at Andijan State Medical Institute range from Rs 20 - 22 Lacs. This includes tuition fees, hostel accommodations, food expenses, and other miscellaneous costs.",
  },
  {
    question:
      "What is the rank of Andijan State Medical Institute in the world?",
    answer:
      "As of 2025, Andijan State Medical Institute holds the 9625th rank globally and the 44th rank in Uzbekistan for medical education, reflecting its academic excellence and reputation.",
  },
  {
    question: "Is Andijan State Medical Institute government or private?",
    answer:
      "Andijan State Medical Institute is a government institution established in 1955, offering quality medical education at an affordable cost.",
  },
];

// Accordion Component
const Accordion = ({ question, answer, isOpen, onToggle }) => {
  const [animationParent] = useAutoAnimate();

  return (
    <div ref={animationParent} className="flex flex-col gap-4 py-4">
      <p
        onClick={onToggle}
        className="flex justify-between gap-2 text-[14px] sm:text-[16px] font-[550]  cursor-pointer"
      >
        <span>{question}</span>
        <Image src={isOpen ? Minus : Plus} alt="Toggle" className="w-5 h-5" />
      </p>
      {isOpen && (
        <p className="text-[14px] sm:text-[16px] text-gray-900">{answer}</p>
      )}
    </div>
  );
};

// FAQ Component
export default function Faq() {
  const [openIndex, setOpenIndex] = useState(null);

  const toggleAccordion = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="lg:w-[95%] lg:mx-auto py-8 p-4">
      {/* Heading */}
      <h2 className="text-[22px] md:text-[28px] font-[700] text-[#16A8AF]   ">
        Andijan State Medical Institute - Important FAQs
      </h2>

      {/* FAQ List */}
      <div className="flex flex-col gap-2 md:gap-4 divide-y  w-[90%] md:w-[90%]  p-3 md:p-0">
        {faqs.map((faq, index) => (
          <Accordion
            key={index}
            question={faq.question}
            answer={faq.answer}
            isOpen={openIndex === index}
            onToggle={() => toggleAccordion(index)}
          />
        ))}
      </div>
    </div>
  );
}
