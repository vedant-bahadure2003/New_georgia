import React from "react";
import Image from "next/image";
import vector from "../../../../public/Images/vector.png";

const WhyStudy = () => {
  return (
    <div className="flex flex-col lg:flex-row lg:w-[95%] lg:mx-auto lg:justify-start items-center lg:items-start  ml-3 ">
      <div className=" flex flex-col py-6 bg-white">
        {/* Title */}
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]  ">
          Why Study MBBS At Andijan State Medical Institute?
        </h2>

        {/* Description */}
        <p className="text-justify font-[550] text-[14px] sm:text-[16px]  pr-4 sm:pr-8 mt-2  ">
          Here are some key benefits of pursuing an MBBS degree at Andijan State
          Medical Institute:
        </p>

        {/* Content Section */}
        <div className="text-[14px] sm:text-[16px] py-3 flex flex-col gap-3 sm:gap-4  pr-4 sm:pr-8">
          {[
            "The institute emphasises practical training and theoretical knowledge, enabling students to grasp concepts effectively.",
            "It offers quality MBBS education at an affordable cost.",
            "All programs are conducted in English, making them suitable for international students.",
            "The institute has strong connections with local and international colleges, enhancing learning opportunities.",
            "Leading organisations, including FAIMER, WHO, NMC and the Ministry of Higher and Secondary Specialised Education of Uzbekistan, recognise it.",
            "There is a modern library, scientific laboratory, and well-equipped classrooms.",
            "The institute offers diverse specialisation options so that students can tailor their medical education to their needs.",
            "High-class and experienced professors guarantee a higher academic experience.",
          ].map((text, index) => (
            <div key={index} className="flex items-start gap-2">
              <Image
                src={vector}
                alt="vector"
                className="h-[16px] w-[16px] sm:h-[18px] sm:w-[18px] mt-1"
              />
              <p className="text-justify">{text}</p>
            </div>
          ))}
        </div>

        {/* Button */}
        {/* <div id="keyfact" className=" mt-6  ">
          <button className="mt-3  text-black p-2 text-xs sm:text-sm font-medium rounded-md   shadow-lg ">
            <span className="text-[#0da9b0] font-medium ">Read More :</span> Why
            Study MBBS at Andijan State Medical Institute?
          </button>
        </div> */}
      </div>
    </div>
  );
};

export default WhyStudy;
