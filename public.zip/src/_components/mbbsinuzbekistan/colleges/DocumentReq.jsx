import React from "react";
import Image from "next/image";
import vector from "../../../../public/Images/vector.png";

const subjectsData = [
  [
    "Anatomy",
    "Pathology",
    "Pharmacology",
    "Surgery",
    "Dermatology",
    "Neurology",
  ],
  [
    "Physiology",
    "Microbiology",
    "Medicine",
    "Orthopedics",
    "Ophthalmology",
    "Psychiatry",
  ],
  [
    "Biochemistry",
    "Forensic Medicine",
    "Pediatrics",
    "ENT",
    "Radiology",
    "Cardiology",
  ],
  [
    "Histology",
    "Pharmacology",
    "Gynecology",
    "Urology",
    "Pulmonology",
    "Oncology",
  ],
  [
    "Embryology",
    "Community Medicine",
    "Psychiatry",
    "Anesthesia",
    "Gastroenterology",
    "Nephrology",
  ],
  [
    "Genetics",
    "Immunology",
    "Dermatology",
    "Neurosurgery",
    "Endocrinology",
    "Hematology",
  ],
  [
    "Medical Ethics",
    "Clinical Medicine",
    "Radiology",
    "Plastic Surgery",
    "Sports Medicine",
    "Geriatrics",
  ],
  [
    "Epidemiology",
    "Emergency Medicine",
    "Cardiology",
    "Critical Care",
    "Palliative Care",
    "Medical Research",
  ],
  [
    "Research Methodology",
    "Toxicology",
    "Forensic Psychiatry",
    "Transplant Surgery",
    "Pain Management",
    "Genomics",
  ],
  [
    "Biostatistics",
    "Rehabilitation Medicine",
    "Nuclear Medicine",
    "Vascular Surgery",
    "Sleep Medicine",
    "Regenerative Medicine",
  ],
  [
    "Health Informatics",
    "Tropical Medicine",
    "Occupational Medicine",
    "Geriatric Psychiatry",
    "Telemedicine",
    "Precision Medicine",
  ],
];

const DocumentReq = () => {
  return (
    <>
      <div className=" flex flex-col lg:w-[95%]  lg:mx-auto py-6 ml-3 bg-white ">
        {/* Section Heading */}
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]">
          Documents Required at Andijan State Medical Institute
        </h2>

        <p className="text-justify font-semibold py-2 text-[14px] sm:text-[16px] text-black">
          Following documents are required at the time of admission to Andijan
          State Medical Institute:
        </p>

        {/* Document List */}
        <div className="flex flex-col gap-4">
          {[
            "Birth certificate",
            "Copy of passport (validity minimum 2 years)",
            "Passing certificates of 10th and 12th standard",
            "Scorecard of qualified NEET-UG examination",
            "12 passport-size photographs",
            "Character certificate",
            "Migration certificate",
            "Transfer certificate",
            "Proof of payment of fees",
            "Financial proof (sufficient balance in the bank)",
          ].map((item, index) => (
            <div key={index} className="flex gap-3 items-start">
              <Image
                src={vector}
                alt="vector"
                width={18}
                height={18}
                className="mt-1 sm:w-[20px] sm:h-[20px]"
              />
              <p className="text-[14px] sm:text-[16px] text-black">{item}</p>
            </div>
          ))}
        </div>

        {/* CTA Button */}
        {/* <div className="mt-6">
        <button className=" text-black py-2 px-4 text-sm sm:text-base rounded-md shadow-lg  w-full sm:w-auto">
          <span id="syllabus" className="text-[#0da9b0] font-medium">
            Read More:
          </span>{" "}
          Why Study MBBS at Andijan State Medical Institute?
        </button>
      </div> */}
      </div>
      <div className="mt-5  lg:w-[95%] ml-3  lg:mx-auto ">
        <h2 className="text-[20px] lg:text-[28px] font-[700] text-[#0da9b0] px-2 sm:px-0">
          Andijan State Medical Institute - MBBS Course Syllabus
        </h2>
        <p className="text-justify font-semibold py-2 text-[14px] sm:text-[16px] text-black px-2 sm:px-0">
          The complete syllabus for studying MBBS at Andijan State Medical
          Institute is as follows:
        </p>

        <div className="w-[95vw]   max-w-full    overflow-x-auto pb-3  scrollbar-thin scrollbar-thumb-[#0da9b0] scrollbar-track-gray-100">
          <table className="w-screen border-collapse border border-black text-[14px] sm:text-[16px] md:text-base">
            <thead>
              <tr className="bg-[#FFF7EE] border-black">
                {[
                  "1st Year",
                  "2nd Year",
                  "3rd Year",
                  "4th Year",
                  "5th Year",
                  "6th Year",
                ].map((year, index) => (
                  <th
                    key={index}
                    className="px-3 sm:px-4 py-2 border border-black font-semibold text-black text-center whitespace-nowrap"
                  >
                    {year}
                  </th>
                ))}
              </tr>
            </thead>

            <tbody>
              {subjectsData.map((row, rowIndex) => (
                <tr key={rowIndex} className="odd:bg-[#FFF7EE] even:bg-white">
                  {row.map((subject, colIndex) => (
                    <td
                      key={colIndex}
                      className="px-3 sm:px-4 py-1.5 sm:py-2 border border-black text-center whitespace-nowrap"
                    >
                      {subject}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};

export default DocumentReq;
