import React from "react";
import vector from "../../../../public/Images/vector.png";
import Image from "next/image";
const Admission = () => {
  return (
    <div className=" flex flex-col lg:w-[95%] lg:mx-auto ml-3 py-6 ">
      {/* Section Heading */}
      <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]">
        Andijan State Medical Institute Admission Process 2024
      </h2>

      {/* Description */}
      <p className="text-justify font-medium py-3 text-[14px] sm:text-[16px] text-black">
        Admission to Andijan State Medical Institute (ASMI) 2025 will begin in
        June and July for the September intake cycle. To seek admission to the
        MBBS program, students can apply directly through the institute's
        official website. For Indian nationals, a good NEET score is required to
        process admission procedures further.
      </p>

      {/* Document List */}
      <div className="flex flex-col gap-4">
        {[
          "Apply Online",
          "Submit Application",
          "Application review by government authorities",
          " Acceptance letter from the University",
          "Visa Application",
        ].map((item, index) => (
          <div key={index} className="flex gap-3 items-start">
            <Image
              src={vector}
              alt="vector"
              width={18}
              height={18}
              className="mt-1 sm:w-[20px] sm:h-[20px]"
            />
            <p className="text-[14px] sm:text-[16px] text-black">{item}</p>
          </div>
        ))}
      </div>

      {/* CTA Button */}
      {/* <div className="mt-3">
        <button
          id="document"
          className=" text-black py-2 px-4 text-sm sm:text-base rounded-md shadow-lg  "
        >
          <span className="text-[#0da9b0] font-medium">Read More:</span>Read
          more to view detailed admission steps and timelines.
        </button>
      </div> */}
    </div>
  );
};

export default Admission;
