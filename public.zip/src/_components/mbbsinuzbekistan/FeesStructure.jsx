import React from "react";

const FeesStructure = () => {
  const feeData = [
    {
      university: "Andijan State Medical Institute",
      tuitionFees: "3500 USD",
      hostelFees: "3500 USD",
    },
    {
      university: "Bukhara State Medical Institute",
      tuitionFees: "3500 USD",
      hostelFees: "3500 USD",
    },
    {
      university: "Samarkand State Medical Institute",
      tuitionFees: "3500 USD",
      hostelFees: "3500 USD",
    },
    {
      university: "Tashkent Medical Academy",
      tuitionFees: "3500 USD",
      hostelFees: "3500 USD",
    },
    {
      university: "Fergana Medical Institute of Public Health",
      tuitionFees: "3500 USD",
      hostelFees: "400 USD",
    },
    {
      university: "Tashkent State Dental Institute",
      tuitionFees: "4200 USD",
      hostelFees: "350 USD",
    },
  ];

  return (
    <>
      <div className=" p-3">
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]  md:text-left">
          MBBS in Uzbekistan Fee Structure 2025-26
        </h2>
        <p className=" text-[14px] sm:text-[16px] font-[450]  md:text-left">
          MBBS in Uzbekistan fees for Indian students range from INR 15 - 23
          lacs for the full six-year course, covering tuition, hostel, medical,
          and other expenses. Monthly living costs are affordable, around INR
          10,000 - 15,000. Below is the structure for MBBS fees in Uzbekistan
          for the 2025-26 season:
        </p>

        {/* Table Section */}
        <div className="overflow-x-auto ">
          <table className="w-full text-sm text-left rtl:text-right border border-black mt-5">
            <thead className="text-sm bg-[#FFF7EE]">
              <tr>
                <th
                  scope="col"
                  className=" text-[14px] sm:text-[16px] px-4 py-2 border border-black text-black text-center"
                >
                  Name of the universities
                </th>
                <th
                  scope="col"
                  className="text-[14px] sm:text-[16px] px-4 py-2 border border-black text-black text-center"
                >
                  Tuition Fees / Year
                </th>
                <th
                  scope="col"
                  className=" text-[14px] sm:text-[16px] px-4 py-2 border border-black text-black text-center"
                >
                  Hostel Fees / Year
                </th>
              </tr>
            </thead>
            <tbody>
              {feeData.map((item, index) => (
                <tr key={index} className="odd:bg-white even:bg-[#FFF7EE]">
                  <td className=" text-[14px] sm:text-[16px] px-4 py-2 border border-black">
                    {item.university}
                  </td>
                  <td className="text-[14px] sm:text-[16px] text-center px-4 py-2 border border-black">
                    {item.tuitionFees}
                  </td>
                  <td
                    id="Eligibility"
                    className=" text-[14px] sm:text-[16px] text-center px-4 py-2 border border-black"
                  >
                    {item.hostelFees}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <p className=" mt-3">
            <span className="font-bold text-[14px] sm:text-[16px]">
              Disclaimer:
            </span>{" "}
            The fees mentioned above are subject to change as per university
            policies. Additional costs such as food, travel, and personal
            expenses are not included in the abovementioned fees.
          </p>
        </div>
      </div>
    </>
  );
};

export default FeesStructure;
