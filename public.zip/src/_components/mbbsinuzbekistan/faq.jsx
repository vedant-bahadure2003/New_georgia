"use client";
import React, { useState } from "react";
import { useAutoAnimate } from "@formkit/auto-animate/react";
import Image from "next/image";
import Minus from "../../../public/Images/minus.png";
import Plus from "../../../public/Images/plus.png";

// FAQ Data
const faqs = [
  {
    question: "What is the duration of the MBBS course in Uzbekistan?",
    answer:
      "The MBBS course in Uzbekistan is a 6-year course including 1 year of internship..",
  },
  {
    question:
      "Is an internship compulsory for studying for an MBBS in Uzbekistan?",
    answer:
      "MBBS in Uzbekistan requires a one-year internship, which is mandatory for the students.",
  },
  {
    question:
      "What is the age requirement to get admission to MBBS in Uzbekistan?",
    answer:
      "All students' admission to the MBBS in Uzbekistan depends on the age group of 17 - 25 years.",
  },
  {
    question: "Is an MBBS degree from Uzbekistan recognised in India?",
    answer:
      "An MBBS degree from Uzbekistan is recognised internationally and anywhere in the world.",
  },
  {
    question: "Is Uzbekistan safe for Indian students?",
    answer:
      "Yes. It is safe for international students to come to the country because the crime rate is very low.",
  },
];

// Accordion Component
const Accordion = ({ question, answer, isOpen, onToggle }) => {
  const [animationParent] = useAutoAnimate();

  return (
    <div ref={animationParent} className="flex flex-col gap-4 py-4">
      <p
        onClick={onToggle}
        className="flex justify-between gap-2 text-[14px] sm:text-[16px] font-[550]  cursor-pointer"
      >
        <span>{question}</span>
        <Image src={isOpen ? Minus : Plus} alt="Toggle" className="w-5 h-5" />
      </p>
      {isOpen && (
        <p className="text-[14px] sm:text-[16px] text-gray-900">{answer}</p>
      )}
    </div>
  );
};

// FAQ Component
export default function Faq() {
  const [openIndex, setOpenIndex] = useState(null);

  const toggleAccordion = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="w-[90%] md:w-[90%] mx-auto mt-[50px] md:mt-[71px]">
      {/* Heading */}
      <h2 className="text-[22px] md:text-[28px] font-[700] text-[#16A8AF]   ">
        MBBS in Uzbekistan - FAQs
      </h2>

      {/* FAQ List */}
      <div className="flex flex-col gap-2 md:gap-4 divide-y  w-[90%] md:w-[90%]  p-3 md:p-0">
        {faqs.map((faq, index) => (
          <Accordion
            key={index}
            question={faq.question}
            answer={faq.answer}
            isOpen={openIndex === index}
            onToggle={() => toggleAccordion(index)}
          />
        ))}
      </div>
    </div>
  );
}
