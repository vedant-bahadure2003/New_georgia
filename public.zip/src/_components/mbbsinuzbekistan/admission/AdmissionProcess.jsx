import Image from "next/image";
import rightsign from "../../../../public/Images/vector.png";
import onlineAppIcon from "../../../../public/Images/online-application.png";
import submitIcon from "../../../../public/Images/submit.png";
import reviewIcon from "../../../../public/Images/review.png";
import acceptIcon from "../../../../public/Images/accept.png";
import visaIcon from "../../../../public/Images/visa.png";

const requiredDocuments = [
  "Fill out the online application form on the institute's official website before the deadline.",
  "Scan and upload your academic documents according to the instructions.",
  "Within 48 hours, you will receive an offer letter from the institute.",
  "After getting the offer letter, you pay the first year's MBBS course fee.",
  "Check whether your passport is valid and apply for a visa.",
  "Wait for approximately 30 days for the visa to be processed.",
  "After getting the approval of the visa, you may start your journey to fulfill your dream of studying MBBS at Andijan State Medical Institute.",
];

const AdmissionProcess = () => {
  return (
    <div className="lg:w-[95%] lg:mx-auto mt-6 ml-6     sm:p-0 ">
      <div className=" py-6  ">
        {/* Heading */}
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]">
          How to Apply for MBBS at Andijan State Medical Institute?
        </h2>
        <p className="mt-2 text-[14px] sm:text-[16px]  text-black">
          International students can follow a direct path to obtain admission at
          Andijan State Medical Institute's MBBS program. Students must register
          using the institute's official website's online application portal
          while submitting the required documents. You receive the admission
          offer within 48 hours after your application.
          <br /> <br />
          You must pay your first-year course fees after receiving the offer
          while making sure your passport remains valid. You need to apply for a
          visa through a process that requires 30 days for the evaluation
          process before the approval is granted, which will make you eligible
          to start your MBBS education at the institute. <br /> <br />
          <span className="font-[550]">
            To apply for MBBS admission, you can follow the following steps:
          </span>
        </p>

        {/* Steps Section */}
        <div className="text-[14px] sm:text-[16px]  flex flex-col gap-2 mt-3">
          {requiredDocuments.map((document, index) => (
            <div
              key={index}
              className="flex gap-3 items-start sm:gap-4 justify-start"
            >
              <Image
                src={rightsign}
                alt="vector"
                className="h-[18px] w-[18px] mt-1"
              />
              <p
                id="syllabus"
                className="text-[14px] sm:text-[16px] text-justify"
              >
                {document}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdmissionProcess;
