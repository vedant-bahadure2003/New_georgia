import Link from "next/link";
import React from "react";

const UzbekistanVsIndiaMbbs = () => {
  const comparisonData = [
    {
      title: "Seat Availability",
      uzbekistan: "Not Limited",
      india: "Limited",
    },
    {
      title: "Fees Structure",
      uzbekistan: "Starting fees: 2.8 lakh/year",
      india:
        "Government College: INR 11,000 to INR 7.5 lakhs (Complete Course) Private college: INR 20 lakhs to INR 80 lakhs (Complete Course)",
    },
    {
      title: "Course Duration",
      uzbekistan: "6 Years (5 years + 1-year Internship)",
      india: "5.5 Years (4.5 years academics + 1-year Internship)",
    },
    {
      title: "Donation",
      uzbekistan: "Donation not required",
      india: "Some colleges take donations for admissions",
    },
    {
      title: "Entrance Exam",
      uzbekistan: "Entrance test is not required",
      india: "Entrance test required (e.g., NEET)",
    },
    {
      title: "Clinical Exposure",
      uzbekistan: "Opportunities for practical exposure are available",
      india:
        "Broad practical exposure in university-affiliated healthcare facilities",
    },

    {
      title: "Cultural Exposure",
      uzbekistan: "Limited cultural exposure due to familiar environment",
      india:
        "Vast cultural exposure to different cultures and diverse patient demographics",
    },
  ];

  return (
    <div className="py-6 px-3 lg:w-[95%] lg:mx-auto sm:px-6 md:px-0">
      <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#16A8AF]">
        MBBS in Uzbekistan vs MBBS in India
      </h2>
      <p className="text-[14px] sm:text-[16px] font-[550] mt-2 my-3">
        Here's a comparison between MBBS in Uzbekistan and India to help you
        decide the best option for pursuing medical education. While Uzbekistan
        offers affordable fees and no entrance test, India has limited seats and
        higher costs.
      </p>

      {/* Comparison Table */}
      <table className="w-full text-[14px] sm:text-[16px] text-left rtl:text-right border border-black mt-4">
        <thead>
          <tr className="bg-[#FFF7EE]">
            <th className="px-3 py-2 border border-black text-center">
              Particulars
            </th>
            <th className="px-3 py-2 border border-black text-center ">
              MBBS in Uzbekistan
            </th>
            <th className="px-3 py-2 border border-black text-center">
              MBBS in India
            </th>
          </tr>
        </thead>
        <tbody>
          {comparisonData.map((item, index) => (
            <tr key={index} className="odd:bg-white even:bg-[#FFF7EE] border">
              <td className="px-3 py-2 border font-bold border-black">
                {item.title}
              </td>
              <td className="px-3 py-2 border border-black">
                {item.uzbekistan}
              </td>
              <td className="px-3 py-2 border border-black">{item.india}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default UzbekistanVsIndiaMbbs;
