import React from "react";
import rightsign from "../../../public/Images/vector.png";
import Image from "next/image";

const Eligibility = () => {
  const eligibilityCriteria = [
    {
      text: " Must have completed 10+2 with a regular board",
    },
    {
      text: "Qualification of NEET is required",
    },
    {
      text: "A minimum of 60% marks should be in physics, chemistry, and biology",
    },
    {
      text: "Basic English language skills (IELTS is not required)",
    },
  ];

  return (
    <>
      {/* Eligibility Criteria for MBBS in Uzbekistan */}
      <div className=" p-3 ">
        <div className="gap-2">
          <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]  md:text-left">
            Eligibility Criteria for MBBS Admission in Uzbekistan
          </h2>
          <p className="text-[14px] sm:text-[16px] font-[550]  md:text-left">
            The eligibility criteria for pursuing an MBBS in Uzbekistan are
            simple, and students must fulfil the basic academic requirements to
            get admitted.
          </p>
        </div>
        <div className=" mt-3">
          <div className="text-[14px] sm:text-[16px] flex flex-col gap-3 md:gap-2">
            {eligibilityCriteria.map((item, index) => (
              <div key={index} className="flex items-start gap-3">
                <Image
                  src={rightsign}
                  alt="vector"
                  className="h-[18px] w-[18px] mt-1"
                />
                <p className="flex gap-2 text-[14px] sm:text-[16px] text-justify">
                  {item.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Eligibility;
