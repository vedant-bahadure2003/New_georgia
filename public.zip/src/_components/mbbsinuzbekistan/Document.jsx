import Image from "next/image";
import React from "react";
import rightsign from "../../../public/Images/vector.png";

const Document = () => {
  // Array of required documents
  const requiredDocuments = [
    "Passport Copy",
    "Academic Mark Sheets",
    "Invitation Letter Copy",
    "Birth Certificate",
    "Medical Examination Report",
    "8 Passport-Sized Photos",
    "COVID-19 Vaccination Certificate",
    "NEET Scorecard",
    "Proof of Age",
    "Valid Identity & Address Proof",
    "Visa-related Documents",
    "HIV Test Negative Report",
    "No Criminal Record Certificate",
    "Travel and Health Insurance Policy",
  ];

  return (
    <>
      {/* Documents Required for MBBS in Uzbekistan */}
      <div id="document" className=" p-3 md:px-0  lg:w-[95%] lg:mx-auto ">
        <div className="flex flex-col justify-center items-start ">
          <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]  md:text-left">
            Documents Required for MBBS in Uzbekistan
          </h2>
          <p className="text-[14px] sm:text-[16px] font-[550]  md:text-left">
            Mentioned below are the documents required for MBBS admission in
            Uzbekistan:
          </p>
        </div>
        <div className="text-[14px] sm:text-[16px]  flex flex-col gap-2 mt-3">
          {requiredDocuments.map((document, index) => (
            <div
              key={index}
              className="flex gap-3 items-start sm:gap-4 justify-start"
            >
              <Image
                src={rightsign}
                alt="vector"
                className="h-[18px] w-[18px] mt-1"
              />
              <p
                id="syllabus"
                className="text-[14px] sm:text-[16px] text-justify"
              >
                {document}
              </p>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Document;
