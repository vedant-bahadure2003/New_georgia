import Image from "next/image";
import React from "react";
import rightsign from "../../../public/Images/vector.png";
const uzbekistanFacts = [
  "Uzbekistan is located in Central Asia; Kazakhstan, Kyrgyzstan, Tajikistan, and Afghanistan surround it.",
  "The country became a sovereign state on August 31, 1991, after the Soviet Union was disbanded.",
  "The state language is Uzbek, the script is Latin, and the widely used language is Russian along with Uzbek.",
  "Uzbekistan shows off a type of climate called continental because of the very hot summers and the cold winters, with temperatures exceeding 40°C in summer.",
  "The central city of Uzbekistan is Tashkent, the biggest one in the country.",
];
const CareerScope = () => {
  const courses = [
    {
      name: "Accommodation",
      duration: "$150 - $250",
    },
    { name: "Food", duration: "$24.4" },
    {
      name: "Transportation",
      duration: "$15.67",
    },
    { name: "Clothing", duration: "Variable" },
    { name: "Other Expenses", duration: "Variable" },
  ];

  const about = [
    {
      name: "Religion",
      duration: "Predominantly Muslim (Sunni Isl am)",
    },
    { name: "Currency", duration: "Uzbekistani Som (UZS)" },
    {
      name: "Language",
      duration: "Turkish (official), Uzbek (predominant)",
    },
    { name: "Exchange Rate", duration: "1 USD = 11,000 UZS (approx.)" },
    { name: "Population", duration: "Around 34 million" },
    {
      name: "Climate",
      duration: "Continental climate: Hot summers, cold winters",
    },
    {
      name: "Time Difference (from India)",
      duration: "+1.5 hours (Uzbekistan is ahead)",
    },
  ];

  return (
    <>
      {/* Career Scope after Completing MBBS from Uzbekistan */}
      {/* <div className="lg:mt-8 lg:w-[95%] lg:mx-auto flex flex-col gap-5 mt-[40px] px-4 md:px-0">
        <div className="flex flex-col justify-center items-start gap-2">
          <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]  md:text-left">
            Career Scope after Completing MBBS from Uzbekistan
          </h2>
          <p className="text-[14px] lg:text-[16px] font-[550]  md:text-left">
            Study MBBS in Uzbekistan and open various career avenues. This makes
            them special, have look at the possibilities:
          </p>
        </div>
        <div className="text-sm sm:text-[18px] flex flex-col gap-2">
          {[...Array(4)].map((_, index) => (
            <div className="flex gap-2" key={index}>
              <Image
                src={rightsign}
                alt="rightsign"
                className="h-[18px] w-[18px] mt-1"
              />
              <p className="flex gap-2 text-justify text-[16px]    ">
                {index === 0 &&
                  "Eligible students need to check the postgraduate options after acquiring the MBBS degree in Uzbekistan. After receiving an MBBS degree from Uzbekistan University, Indian college students can review the eligibility standards for pursuing postgraduate research in India in addition to abroad."}
                {index === 1 &&
                  "Uzbekistan offers the best precedence to medical studies improvement. Students of the medical University are offered diverse possibilities to work with the main scientists of the world."}
                {index === 2 &&
                  "Students can work and make contributions to the improvement of the medical field which opens new professional paths for college students interested in studies and improvement in the medical field."}
                {index === 3 &&
                  "More opportunities will arise as medical education continues to improve in Uzbekistan."}
              </p>
            </div>
          ))}
        </div>
      </div> */}

      {/* Impact Of NMC Gazette On MBBS In Uzbekistan */}
      {/* <div className="lg:mt-20 lg:w-[95%] lg:mx-auto flex flex-col gap-5 mt-[5px] p-1 px-4 md:px-0">
        <div className="flex flex-col justify-center items-start gap-2">
          <h2 className="text-[24px] font-[700] w-full sm:w-[550px] text-[#0da9b0]  md:text-left">
            Impact Of NMC Gazette On MBBS In Uzbekistan
          </h2>
          <p className="text-sm font-semibold  md:text-left">
            Study MBBS in Uzbekistan and open various career avenues. This makes
            them special, have a look at the possibilities:
          </p>
        </div>
        <div className="text-sm sm:text-[18px] flex flex-col gap-2">
          {[...Array(2)].map((_, index) => (
            <div className="flex gap-2" key={index}>
              <Image
                src={rightsign}
                alt="rightsign"
                className="h-[18px] w-[18px] mt-1"
              />
              <p className="text-base gap-2 text-justify">
                <b className="font-semibold">
                  {index === 0 ? "Rule 1:" : "Rule 2:"}
                </b>{" "}
                {index === 0 &&
                  "Eligible students need to check the postgraduate options after acquiring the MBBS degree in Uzbekistan. After receiving an MBBS degree from Uzbekistan University, Indian college students can review the eligibility standards for pursuing postgraduate research in India in addition to abroad."}
                {index === 1 &&
                  "Uzbekistan offers the best precedence to medical studies improvement. Students of the medical University are offered diverse possibilities to work with the main scientists of the world."}
              </p>
            </div>
          ))}
        </div>
      </div> */}

      {/* Medium Of Teaching In Uzbekistan */}
      <div className="lg:mt-8 lg:w-[95%] lg:mx-auto flex flex-col gap-1 mt-[5px] px-4 md:px-0">
        <div className="flex flex-col justify-center items-start gap-2">
          <h2 className="text-[22px] lg:text-[28px] font-[700] w-full sm:w-[500px] text-[#0da9b0] md:text-left">
            Medium of Teaching In Uzbekistan
          </h2>
        </div>
        <div className=" flex flex-col gap-2">
          <div className=" flex flex-col gap-2">
            <div className="flex gap-2">
              <p className=" text-[14px] sm:text-[16px]  flex gap-2 text-justify">
                In Uzbekistan, the principal medium of instruction for MBBS is
                English only. Almost all the medical universities in Uzbekistan
                offer MBBS in English to students from other countries. <br />
                In this way, international students can quickly pursue the
                course of medicine in Uzbekistan, irrespective of their native
                language.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Is NEET Required For MBBS In Uzbekistan? */}
      {/* <div className=" lg:mt-8 lg:w-[95%] lg:mx-auto flex flex-col gap-1 mt-[5px] p-1 px-4 md:px-0">
        <div className="flex flex-col justify-center items-start gap-2">
          <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]  md:text-left">
            Is NEET Required For MBBS In Uzbekistan?
          </h2>
        </div>
        <div className=" flex flex-col gap-2">
          <div className=" flex flex-col gap-2">
            <div className="flex gap-2">
              <p className=" text-[14px] lg:text-[16px]  flex gap-2 text-justify">
                Eligible students need to check the postgraduate options after
                acquiring the MBBS degree in Uzbekistan. After receiving an MBBS
                degree from Uzbekistan University, Indian college students can
                review the eligibility standards for pursuing postgraduate
                research in India in addition to abroad.
              </p>
            </div>
          </div>
        </div>
      </div> */}

      {/*Cost of Living in Uzbekistan */}
      <div className="px-4 lg:w-[95%] lg:mx-auto mt-8 md:px-0">
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#16A8AF]  md:text-left">
          Cost of Living in Uzbekistan
        </h2>
        <p className="text-[14px] sm:text-[16px] font-[550] mt-2 my-3  md:text-left">
          The cost of living in Uzbekistan is affordable, whereas meals,
          groceries, and transportation are reasonable factors. Rent may be
          between $150 and $250 per month, which is an economical option for
          students who plan to study internationally.
        </p>

        {/* Dynamic Courses Table */}
        <table className="w-full text-[14px] sm:text-[16px] text-left rtl:text-right border border-black mt-5">
          <thead>
            <tr className="odd:bg-[#FFF7EE] even:bg-white border">
              <th className="px-4 py-2 border border-black  text-black text-center">
                Category
              </th>
              <th className="px-4 py-2 border border-black text-black text-center">
                Cost (USD)
              </th>
            </tr>
          </thead>
          <tbody>
            {/* Map through the courses data */}
            {courses.map((course, index) => (
              <tr
                key={index}
                className={`odd:bg-white even:bg-[#FFF7EE] ${
                  index % 2 === 0 ? "bg-white" : "bg-[#FFF7EE]"
                }`}
              >
                <td className="px-4 py-2 border border-black">{course.name}</td>
                <td className="px-4 py-2 border border-black text-center">
                  {course.duration}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* How Safe Is Uzbekistan For Indian Students? */}
      <div className="lg:w-[95%] lg:mx-auto lg:mt-8 flex flex-col gap-2 mt-[5px] py-2 px-4 md:px-0">
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0] md:text-left">
          About Uzbekistan
        </h2>
        <div className="flex flex-col justify-center items-start w-full gap-2">
          <div className="text-[14px] sm:text-[16px] flex flex-col gap-2 w-full sm:w-[90%]">
            <ul className="list-none pl-3 space-y-2">
              {uzbekistanFacts.map((fact, index) => (
                <li key={index} className="flex gap-2 items-start">
                  <Image
                    src={rightsign}
                    alt="vector"
                    className="h-[18px] w-[18px] mt-1"
                  />
                  <span>{fact}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <p className="text-[14px] sm:text-[16px] font-[550] mt-6">
          Here is some interesting information about Uzbekistan:
        </p>
        <table className="w-full text-sm text-left rtl:text-right border border-black">
          <thead>
            <tr className="odd:bg-[#FFF7EE] even:bg-white border">
              <th className="px-4 py-2 border border-black text-black text-center">
                Aspect
              </th>
              <th className="px-4 py-2 border border-black text-black text-center">
                Details
              </th>
            </tr>
          </thead>
          <tbody>
            {about.map((item, index) => (
              <tr
                key={index}
                className={`odd:bg-white even:bg-[#FFF7EE] ${
                  index % 2 === 0 ? "bg-white" : "bg-[#FFF7EE]"
                }`}
              >
                <td className="px-4 py-2 border border-black">{item.name}</td>
                <td className="px-4 py-2 border border-black text-center">
                  {item.duration}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default CareerScope;
