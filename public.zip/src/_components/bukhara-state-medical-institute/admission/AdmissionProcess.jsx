import Image from "next/image";
import rightsign from "../../../../public/Images/vector.png";
import onlineAppIcon from "../../../../public/Images/online-application.png";
import submitIcon from "../../../../public/Images/submit.png";
import reviewIcon from "../../../../public/Images/review.png";
import acceptIcon from "../../../../public/Images/accept.png";
import visaIcon from "../../../../public/Images/visa.png";

const AdmissionProcess = () => {
  const admissionSteps = [
    {
      step: 1,
      description:
        " Fill up all the points of your interest with the application form of the institute",
    },
    {
      step: 2,
      description:
        "Scan and upload your academic documents according to the instructions",
    },
    {
      step: 3,
      description:
        " Within 48 hours, you will receive an offer letter from the institute. Save it for further usage.",
    },
    {
      step: 4,
      description:
        " You must pay all the enrollment charges to the University or college. ( Pay the first year's MBBS course fee.)",
    },
    {
      step: 5,
      description:
        " Apply for a Visa (Wait approximately 30 days for the visa to be processed.",
    },
    {
      step: 6,
      description: "  Get a student visa to study MBBS.",
    },
    {
      step: 7,
      description:
        "  Book a flight to Uzbekistan and start your journey to fulfill your dream of studying MBBS at Bukhara State Medical Institute.",
    },
  ];

  return (
    <div className="lg:w-[95%] lg:mx-auto mt-6 ml-6     sm:p-0 ">
      <div className=" py-6  ">
        {/* Heading */}
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]">
          How to Apply for MBBS at Bukhara State Medical Institute?
        </h2>
        <p className="mt-2 text-[14px] sm:text-[16px]  text-black">
          The admission process at Bukhara State Medical Institute is
          straightforward and hassle-free. To apply for the MBBS program,
          candidates must follow a simple procedure, which includes submitting
          the necessary academic documents, completing the application form, and
          meeting the eligibility criteria. The institute provides clear
          guidelines to ensure smooth processing of applications. Additionally,
          students are required to provide proof of medical fitness and
          financial capability to support their studies. Once the application is
          reviewed and accepted, candidates will receive an invitation letter to
          begin their studies.
        </p>

        {/* Steps Section */}
        <div className="mt-5 ">
          <div className="text-[14px] sm:text-[16px] flex flex-col gap-4 text-black">
            {admissionSteps.map((stepItem, index) => (
              <div key={index} className="flex  ">
                <p className="w-[60px] text-[#0da9b0] font-[700] text-[14px] sm:text-[16px] ">
                  Step {stepItem.step}:
                </p>
                <p className="  flex-1 text-[14px] sm:text-[16px]">
                  {stepItem.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdmissionProcess;
