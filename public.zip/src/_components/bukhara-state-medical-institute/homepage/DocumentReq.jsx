import React from "react";
import Image from "next/image";
import vector from "../../../../public/Images/vector.png";

const subjectsData = [
  // 1st Year
  [
    "Medical Chemistry",
    "Histology",
    "Human Anatomy",
    "Bioorganic Chemistry",
    "Cytology, Embryology",
    "Patient Care",
  ],
  // 2nd Year
  [
    "Physiology",
    "Biochemistry",
    "Microbiology",
    "Emergency Medicine",
    "Elective Courses",
  ],
  // 3rd Year
  [
    "Pathology",
    "Pharmacology",
    "General Surgery",
    "Internal Medicine",
    "Pediatrics",
    "Elective Courses",
  ],
  // 4th Year
  [
    "Community Medicine",
    "ENT, Ophthalmology",
    "Orthopedics",
    "Forensic Medicine",
    "Elective Courses",
  ],
  // 5th Year
  [
    "Infectious Diseases",
    "General Practice",
    "Gynecology",
    "Obstetrics",
    "Traumatology",
    "Oncology",
  ],
  // 6th Year
  ["Internship: Hands-on clinical training in various medical departments"],
];

const DocumentReq = () => {
  return (
    <>
      <div className="flex flex-col lg:w-[95%] lg:mx-auto py-6 ml-3 bg-white">
        {/* Section Heading */}
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]">
          Documents Required at Bukhara State Medical Institute
        </h2>

        <p className="text-justify font-semibold py-2 text-[14px] sm:text-[16px] text-black">
          The following documents are necessary at the time of admission to
          Bukhara State Medical Institute:
        </p>

        {/* Document List */}
        <div className="flex flex-col gap-4">
          {[
            "Birth certificate",
            "Copy of passport (validity minimum 2 years)",
            "Passing certificates of 10th and 12th standard",
            "Scorecard of qualified NEET-UG examination",
            "12 passport-size photographs",
            "Character certificate",
            "Migration certificate",
            "Transfer certificate",
            "Proof of payment of fees",
            "Financial proof (sufficient balance in the bank)",
          ].map((item, index) => (
            <div key={index} className="flex gap-3 items-start">
              <Image
                src={vector}
                alt="vector"
                width={18}
                height={18}
                className="mt-1 sm:w-[20px] sm:h-[20px]"
              />
              <p className="text-[14px] sm:text-[16px] text-black">{item}</p>
            </div>
          ))}
        </div>
      </div>

      {/* MBBS Syllabus Section */}
      <div className="mt-5 lg:w-[95%] ml-3 lg:mx-auto">
        <h2 className="text-[20px] lg:text-[28px] font-[700] text-[#0da9b0] px-2 sm:px-0">
          Bukhara State Medical Institute - MBBS Syllabus
        </h2>
        <p className="text-justify font-semibold py-2 text-[14px] sm:text-[16px] text-black px-2 sm:px-0">
          Bukhara State Medical Institute has structured the MBBS syllabus so
          that students have a solid foundation in medical science. Here's an
          overview of the syllabus by year:
        </p>

        <div className="w-[95vw] max-w-full overflow-x-auto pb-3 scrollbar-thin scrollbar-thumb-[#0da9b0] scrollbar-track-gray-100">
          <table className="w-screen border-collapse border border-black text-[14px] sm:text-[16px] md:text-base">
            <thead>
              <tr className="bg-[#FFF7EE] border-black">
                {[
                  "1st Year",
                  "2nd Year",
                  "3rd Year",
                  "4th Year",
                  "5th Year",
                  "6th Year",
                ].map((year, index) => (
                  <th
                    key={index}
                    className="px-3 sm:px-4 py-2 border border-black font-semibold text-black text-center whitespace-nowrap"
                  >
                    {year}
                  </th>
                ))}
              </tr>
            </thead>

            <tbody>
              {subjectsData[0].map((_, rowIndex) => (
                <tr key={rowIndex} className="odd:bg-[#FFF7EE] even:bg-white">
                  {subjectsData.map((yearSubjects, colIndex) => (
                    <td
                      key={colIndex}
                      className="px-3 sm:px-4 py-1.5 sm:py-2 border border-black text-center whitespace-nowrap"
                    >
                      {yearSubjects[rowIndex] || "-"}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="text-justify font-semibold py-2 text-[14px] sm:text-[16px] text-black px-2 sm:px-0">
          This syllabus allows for step-by-step, in-depth learning so students
          can confidently address real-world medical challenges.
        </p>
      </div>
    </>
  );
};

export default DocumentReq;
