import React from "react";
import universityimg from "../../../../public/Images/hat.png";
import vector from "../../../../public/Images/vector.png"; // ✅ Importing vector properly
import Image from "next/image";

const CourseOffered = () => {
  return (
    <>
      {/* Accreditation Section */}
      <div className="bg-[#FFF9EA] ml-3 lg:w-[95%] lg:mx-auto md:p-12 p-6 rounded-md shadow-md shadow-gray-400">
        <h2 className="text-[#00a1ab] text-[22px] lg:text-[28px] font-[700] mb-4">
          Bukhara State Medical Institute - Accreditation & Recognition
        </h2>
        <p className="text-[14px] sm:text-[16px]">
          Bukhara State Medical Institute has accreditations from several highly
          regarded medical organisations, which confirm the quality of education
          and programs. Such certification helps ensure the institute meets high
          international standards and is recognised as a good choice for
          students worldwide. The following are the principal accrediting
          bodies:
        </p>

        <div className="flex justify-center items-center mb-6">
          <div className="relative">
            <Image
              src={universityimg}
              alt="University Image"
              width={176} // Explicit width
              height={128} // Explicit height
              className="w-32 h-24 sm:w-44 sm:h-32"
            />
          </div>
        </div>

        <ul className="space-y-2 text-gray-800 text-[14px] sm:text-[16px]">
          <li className="flex items-start gap-2">
            <span className="text-yellow-500">⭐</span>
            Ministry of Higher and Secondary Specialized Education, Uzbekistan
          </li>
          <li className="flex items-start gap-2">
            <span className="text-yellow-500">⭐</span>
            World Health organisation (WHO)
          </li>
          <li className="flex items-start gap-2">
            <span className="text-yellow-500">⭐</span>
            Recognised AIMER
          </li>
          <li className="flex items-start gap-2">
            <span className="text-yellow-500">⭐</span>
            National Medical Commission (NMC)
          </li>
          <li className="flex items-start gap-2">
            <span className="text-yellow-500">⭐</span>
            Recognised by - United Nations Educational, Scientific and Cultural
            organisation (UNESCO)
          </li>
        </ul>
      </div>

      {/* Students life */}
      <div
        id="Intake"
        className=" lg:w-[95%] ml-3 lg:mx-auto flex flex-col gap-2 mt-[30px] p-1"
      >
        <div className="flex flex-col justify-center items-start gap-2">
          <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]">
            Students Life at Bukhara State Medical Institute
          </h2>
        </div>
        <div className="text-[14px] sm:text-[16px] flex flex-col  ">
          <div className="text-[14px] sm:text-[16px] flex flex-col ">
            <div className="flex gap-2">
              <p className="flex gap-2 text-[14px] sm:text-[16px]">
                The Bukhara State Medical Institute campus offers a great
                environment to study and live. Located in Bukhara, this city
                provides a confluence of culture, a variety of cuisines,
                shopping, and much more, making it exciting for international
                students.
                <br /> <br />
                It has state-of-the-art facilities and upgraded amenities that
                foster student life. Professional maintenance teams are assigned
                to keep the campus in good condition, with all its facilities
                well-maintained to make students feel at ease while on campus.
                <br /> <br />
                The campus and residence halls are under 24-hour security to
                ensure the safety of all students. That, combined with a
                friendly atmosphere, makes BSMI an excellent choice for students
                seeking a fulfilling and secure educational experience.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Hostel & Accommodation at Andijan State Medical Institute */}

      <div className=" flex flex-col lg:w-[95%] lg:mx-auto py-6 ml-3 bg-white ">
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]">
          Bukhara State Medical Institute - Hostel & Accommodation
        </h2>

        <p className="text-justify font-semibold py-2 text-[14px] sm:text-[16px] text-black">
          The university offers accommodation and hostels for international
          students. It has well-furnished and spacious hostels for students.{" "}
          <br />
          At the hostel, the students are also offered some amenities like
          groceries, transport means, public internet, sophisticated
          laboratories and so on at a cheaper price than other places.
          <br />
          Both male and female hostels have individual rooms that are well
          equipped with all the necessary furniture and equipment and are
          reasonably comfortable.
        </p>

        {/* Document List */}
        <div className="flex flex-col gap-4">
          {[
            "Reading Hall  ",
            "Cafeteria ",
            "Sports ground.",
            "Self-kitchen system",
            "Modern laboratories",
            "Gymnasium",
          ].map((item, index) => (
            <div key={index} className="flex gap-3 items-start">
              <Image
                src={vector}
                alt="vector"
                width={18}
                height={18}
                className="mt-1 sm:w-[20px] sm:h-[20px]"
              />
              <p className="text-[14px] sm:text-[16px] text-black">{item}</p>
            </div>
          ))}
        </div>

        {/* CTA Button */}
        {/* <div className="mt-6">
              <button className=" text-black py-2 px-4 text-sm sm:text-base rounded-md shadow-lg  w-full sm:w-auto">
                <span id="syllabus" className="text-[#0da9b0] font-medium">
                  Read More:
                </span>{" "}
                Why Study MBBS at Andijan State Medical Institute?
              </button>
            </div> */}
      </div>

      {/* Duration */}
      {/* <div
        id="Intake"
        className=" lg:w-[95%] ml-3 lg:mx-auto flex flex-col gap-2 mt-[30px] p-1"
      >
        <div className="flex flex-col justify-center items-start gap-2">
          <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]">
            Duration of MBBS at Andijan State Medical Institute
          </h2>
        </div>
        <div className="text-[14px] sm:text-[16px] flex flex-col  ">
          <div className="text-[14px] sm:text-[16px] flex flex-col ">
            <div className="flex gap-2">
              <p className="flex gap-2 text-[14px] sm:text-[16px]">
                The duration of the MBBS course at Andijan State Medical
                Institute is 6 years, which further consists of 5 years of
                academic study and 1 year of internship. The first 3 years focus
                on the theoretical aspects of medicine, while the next 3 years
                are dedicated to practical training.
              </p>
            </div>
          </div>
        </div>
      </div> */}
    </>
  );
};

export default CourseOffered;
