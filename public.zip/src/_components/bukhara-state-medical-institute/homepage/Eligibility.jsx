import React from "react";
import Image from "next/image";
import vector from "../../../../public/Images/vector.png";

// Eligibility criteria data
const eligibilityCriteria = [
  "Students must be 17 years old by December 31 of the admission year.",
  "Applicants must have completed 10+12 (or equivalent) in Physics, Biology, Chemistry, and English.",
  "50% aggregate in Physics, Chemistry, and Biology (PCB) for general category students.",
  "45% aggregate in PCB subjects for ST/SC/OBC students.",
  "Passing the NEET exam is mandatory for admission.",
];

const Eligibility = () => {
  return (
    <div className="flex flex-col py-6 lg:py-10 p-2">
      {/* Title */}
      <h2 className="text-[22px] lg:text-[28px] font-bold text-[#0da9b0]">
        Eligibility Criteria to Study MBBS at Bukhara State Medical Institute
      </h2>
      <p className="text-[14px] sm:text-[16px] font-[550]">
        Ensure you meet the following criteria before applying to Bukhara State
        Medical Institute:
      </p>

      {/* Eligibility List */}
      <div className="text-[14px] sm:text-[16px] ml-3 py-4 bg-[#FFF9EA] flex flex-col gap-4">
        {eligibilityCriteria.map((point, index) => (
          <div key={index} className="flex gap-3">
            <Image
              src={vector}
              alt="vector"
              className="h-[16px] w-[16px] sm:h-[18px] sm:w-[18px] mt-1"
            />
            <p className="text-justify text-[14px] sm:text-[16px]">{point}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Eligibility;
