import React from "react";
import vector from "../../../../public/Images/vector.png";
import Image from "next/image";

const Admission = () => {
  return (
    <div className=" flex flex-col lg:w-[95%] lg:mx-auto ml-3 py-6 ">
      {/* Section Heading */}
      <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]">
        Bukhara State Medical Institute Admission Process 2025
      </h2>

      {/* Description */}
      <p className="text-justify font-medium py-3 text-[14px] sm:text-[16px] text-black">
        Admission to Bukhara State Medical Institute 2025 will begin in the
        September intake cycle. To get admission, Indian students must clear the
        National Eligibility Entrance Exam (NEET). Below are the steps for the
        admission process:
      </p>

      {/* Document List */}
      <div className="flex flex-col gap-4">
        {[
          "Fill out the application form, making sure all details and preferences are correctly entered.",
          "After submission, download the offer letter for future use.",
          "Meet all the enrollment costs as required by the university.",
          "Apply for a student visa for your MBBS education.",
          "Once your visa is secured, proceed to book your flight to Uzbekistan.",
        ].map((item, index) => (
          <div key={index} className="flex gap-3 items-start">
            <Image
              src={vector}
              alt="vector"
              width={18}
              height={18}
              className="mt-1 sm:w-[20px] sm:h-[20px]"
            />
            <p className="text-[14px] sm:text-[16px] text-black">{item}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Admission;
