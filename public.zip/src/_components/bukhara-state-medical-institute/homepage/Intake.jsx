import React from "react";
import vector from "../../../../public/Images/vector.png";
import Image from "next/image";

const Intake = () => {
  return (
    <>
      {/* MBBS Fees in Uzbekistan Section */}
      <div
        id="Intake"
        className=" lg:w-[95%] ml-3 lg:mx-auto flex flex-col gap-2 mt-[30px] p-1"
      >
        <div className="flex flex-col justify-center items-start gap-2">
          <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]">
            Bukhara State Medical Institute MBBS Duration
          </h2>
          <p className="text-[14px] sm:text-[16px] font-semibold">
            The MBBS course duration in Bukhara State Medical Institute is 6
            years, which consists of 5 years of academic study and 1 year of
            internship. The first 5 years focus on the theoretical aspects of
            medicine, while the last year is dedicated to practical training.
          </p>
        </div>
        <table className="w-full text-[14px] sm:text-[16px] text-left rtl:text-right border border-black">
          <tbody>
            <tr className="odd:bg-[#FFF7EE] even:bg-white border">
              <td className="px-4 py-2 border border-black text-center font-[700]">
                Course
              </td>
              <td className="px-4 py-2 border border-black text-center font-[700]">
                Duration
              </td>
            </tr>
            <tr className="odd:bg-[#FFF7EE] even:bg-white">
              <td className="px-4 py-2 border border-black">MBBS</td>
              <td className="px-4 py-2 border border-black">5 + 1 years</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Intake and deadline  */}
      <div className=" hidden lg:flex lg:w-[95%] lg:mx-auto   flex-col gap-3 py-6">
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]">
          Bukhara State Medical Institute - Admission Dates & Deadlines 2025 -26
        </h2>
        <p className="text-[14px] sm:text-[16px] font-semibold">
          The admission dates for the 2025 - 26 intake cycle at Bukhara State
          Medical Institute are as follows:
        </p>
        <table className="w-full text-[14px] sm:text-[16px] text-left rtl:text-right border border-black">
          <tbody>
            <tr className="odd:bg-[#FFF7EE] even:bg-white border">
              <td className="px-4 py-2 border border-black font-medium">
                Events
              </td>
              <td className="px-4 py-2 border border-black">Second Year</td>
            </tr>
            <tr className="odd:bg-[#FFF7EE] even:bg-white">
              <td className="px-4 py-2 border border-black">
                Commencement of 2024 intake cycle
              </td>
              <td className="px-4 py-2 border border-black">September 2025</td>
            </tr>
            <tr className="odd:bg-[#FFF7EE] even:bg-white">
              <td className="px-4 py-2 border border-black">
                Commencement of Application
              </td>
              <td className="px-4 py-2 border border-black">September 2025</td>
            </tr>
            <tr className="odd:bg-[#FFF7EE] even:bg-white">
              <td className="px-4 py-2 border border-black">Admission Later</td>
              <td className="px-4 py-2 border border-black">
                within the next 3-4 weeks
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Mobile View */}
      <div className="lg:hidden lg:w-[95%] lg:mx-auto  ">
        <div className="flex flex-col gap-3 py-4 px-4">
          <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#16A8AF]">
            Bukhara State Medical Institute - Admission Dates & Deadlines 2025
            -26
          </h2>
          <p className="text-[14px] sm:text-[16px] font-semibold">
            The admission dates for the 2025 - 26 intake cycle at Bukhara State
            Medical Institute are as follows:
          </p>
          <table className="w-full text-[14px] sm:text-[16px] text-left rtl:text-right border border-black">
            <tbody>
              <tr className="odd:bg-[#FFF7EE] even:bg-white border">
                <td className="px-2 py-1 border border-black font-medium">
                  Commencement of 2025 intake cycle
                </td>
                <td className="px-2 py-1 border border-black">
                  September 2025
                </td>
              </tr>
              <tr className="odd:bg-[#FFF7EE] even:bg-white">
                <td className="px-2 py-1 border border-black">
                  Commencement of Application
                </td>
                <td className="px-2 py-1 border border-black">
                  September 2025
                </td>
              </tr>
              <tr className="odd:bg-[#FFF7EE] even:bg-white">
                <td className="px-2 py-1 border border-black">
                  Admission Letter
                </td>
                <td className="px-2 py-1 border border-black">
                  within the next 3-4 weeks
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="  lg:flex lg:w-[95%] lg:mx-auto   flex-col gap-3 ml-3 py-6">
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#16A8AF]">
          Bukhara State Medical Institute Ranking
        </h2>
        <p className="text-[14px] sm:text-[16px] font-semibold">
          As per 4icu.org, Bukhara State Medical Institute holds notable
          rankings nationally and globally, reflecting its academic excellence
          and reputation:
        </p>
        <table className="w-full text-[14px] sm:text-[16px] text-left rtl:text-right border border-black">
          <tbody>
            <tr className="odd:bg-[#FFF7EE] even:bg-white border">
              <td className="px-4 py-2 border border-black font-medium">
                Country
              </td>
              <td className="px-4 py-2 border border-black">World</td>
            </tr>
            <tr className="odd:bg-[#FFF7EE] even:bg-white border">
              <td className="px-4 py-2 border border-black font-medium">38</td>
              <td className="px-4 py-2 border border-black">9102</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Medium of teaching */}
      <div
        id="Intake"
        className=" lg:w-[95%] ml-3 lg:mx-auto flex flex-col gap-2 mt-[30px] p-1"
      >
        <div className="flex flex-col justify-center items-start gap-2">
          <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]">
            Medium of Teaching in Bukhara State Medical Institute
          </h2>
        </div>
        <div className="text-[14px] sm:text-[16px] flex flex-col  ">
          <div className="text-[14px] sm:text-[16px] flex flex-col ">
            <div className="flex gap-2">
              <p className="flex gap-2 text-[14px] sm:text-[16px]">
                Bukhara State Medical Institute’s MBBS program is conducted in
                English, making it very popular among Indian and international
                students. Since the instruction language is English, students
                will have better comprehension and a more significant influx of
                students from around the globe.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Infrastructure and facilities */}
      <div className="flex flex-col lg:w-[95%] lg:mx-auto lg:flex-row lg:justify-start items-center lg:items-start lg:mt-20 ml-3">
        <div className=" flex flex-col py-6 bg-white">
          {/* Title */}
          <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]  ">
            Infrastructure & Facilities at Bukhara State Medical Institute
          </h2>

          {/* Description */}
          <p className="text-justify font-semibold text-[14px] sm:text-[16px] pr-4 sm:pr-8 mt-3 sm:mt-4">
            .The Bukhara State Medical Institute, located in Uzbekistan offers
            an array of facilities and infrastructure for its students that
            include:
          </p>

          {/* Content Section */}
          <div className="text-[14px] sm:text-[16px] py-3 flex flex-col gap-3 sm:gap-4 mt-4 sm:mt-6 pr-4 sm:pr-8">
            {[
              "The classes are equipped with projectors for lectures.",
              "The school has well-established medical study facilities.",
              "The school offers spacious furnished hostels for both male and female students separately, with WADSD.",
              "The school has a modern canteen that offers a variety of foods such as Indian, vegetarian, and non-vegetarian dishes.",
              "With all the required facilities, the hall caters to every department.",
              "Musical, dance, and some other cultural activities for the students.",
              "The college offers free sessions for various sports, with table tennis and football available on and around the campus.",
              "Placed throughout the board for the safety of the students.",
              "There are enough security personnel in the Student Hostel; they actively monitor to prevent any illegal activities.",
            ].map((text, index) => (
              <div
                id="accrediation"
                key={index}
                className="flex items-start gap-2"
              >
                <Image
                  src={vector}
                  alt="vector"
                  className="h-[16px] w-[16px] sm:h-[18px] sm:w-[18px] mt-1"
                />
                <p className="text-justify text-[14px] sm:text-[16px]">
                  {text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Intake;
