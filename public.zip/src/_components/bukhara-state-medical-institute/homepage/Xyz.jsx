"use client";

import { useState } from "react";
import Image from "next/image";
import Profile from "../../../../public/Images/profile.png";
import greentick from "../../../../public/Images/greentick.png";

const Xyz = () => {
  return (
    <>
      {" "}
      {/* Xyz employee */}
      <div className="  py-3 w-full  ">
        <div className=" sm:mt-[40px]   ">
          <div className=" bg-white rounded-md">
            <div className="flex gap-3 w-full h-[3.125rem] items-center px-4 sm:px-6">
              <div className="w-[50px] h-[50px]">
                <Image
                  src={Profile}
                  alt="profile"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="font-semibold">
                <h2>Vedant Bahadure</h2>
              </div>
              <div>
                <Image
                  src={greentick}
                  alt="greentick"
                  className="w-[23px] h-[23px]"
                />
              </div>
            </div>
            <div className=" text-justify  w-full text-[14px] sm:text-[16px]  leading-5 py-3 px-4 sm:px-6 relative">
              <p>
                <span className="font-[550]">
                  {" "}
                  Bukhara State Medical Institute{" "}
                </span>{" "}
                is a top medical university offering MBBS program. It is a
                government educational institute. Founded in 1990 in the
                historic city of Bukhara, Uzbekistan, it is one of the
                favourites for international students who want to study MBBS in
                Uzbekistan.
                <br /> <br />
                As a top medical university, it has six faculties: General
                Medicine, Dentistry, Medical Education, Higher Nursing,
                Pediatrics, Medical Biology, and Medical Prevention.
                <br /> <br />
                All lectures delivered at Bukhara State Medical Institute are in
                English; therefore, there are no language difficulties in
                learning, which is quite easy for foreign students.
                <br /> <br />
                The institute is also affiliated with several international
                organisations, including the National Medical Commission (NMC),
                the World Health Organisation (WHO), the United Nations
                Educational Scientific and Cultural Organisation (UNESCO), and
                other international organisations. The total fee for the 6-year
                MBBS program at Bukhara State Medical Institute (BSMI) in
                Uzbekistan for Indian students is approximately $19,200 USD.
                This fee covers tuition, hostel accommodation, food, living
                expenses, and other associated costs. <br /> <br />
                Bukhara State Medical Institute has a magnificent infrastructure
                with pupils from numerous countries. The institution ensures
                that education is provided soundly there, so it is great to
                become a medical practitioner.
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Xyz;
