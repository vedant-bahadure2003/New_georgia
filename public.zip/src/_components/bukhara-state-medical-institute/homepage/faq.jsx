"use client";
import React, { useState } from "react";
import { useAutoAnimate } from "@formkit/auto-animate/react";
import Image from "next/image";
import Minus from "../../../../public/Images/minus.png";
import Plus from "../../../../public/Images/plus.png";

// FAQ Data
const faqs = [
  {
    question: " Is Bukhara State Medical Institute recognised internationally?",
    answer:
      "Bukhara State Medical Institute is recognised worldwide by international medical institutions such as the WHO and NMC. Its graduates' MBBS degree is widely accepted worldwide and practised in other countries.",
  },
  {
    question:
      "What is the medium of instruction for MBBS at Bukhara State Medical Institute?",
    answer:
      "English is the language of instruction for the MBBS program. This ensures that international students can communicate fluently and easily understand the subject matter during their stay at the institution.",
  },
  {
    question:
      "What is the duration of the MBBS program at Bukhara State Medical Institute?",
    answer:
      "The MBBS course at Bukhara State Medical Institute is a 6-year course. 5 years of academics and 1 year of clinical internship.",
  },
  {
    question: " Is NEET mandatory for admission to the MBBS program?",
    answer:
      "Yes, qualifying in NEET or National Eligibility cum Entrance Test is a compulsion for all Indian students entering the MBBS course at Bukhara State Medical Institute because after passing this course, only NEET allows them to practice as a doctor or medical practitioner in India.",
  },
  {
    question:
      "Does Bukhara State Medical Institute provide hostel facilities for international students?",
    answer:
      "Yes, the institute has comfortable and affordable hostel facilities for international students. All the hostels have all the basic amenities to ensure a safe and student-friendly environment.",
  },
];

// Accordion Component
const Accordion = ({ question, answer, isOpen, onToggle }) => {
  const [animationParent] = useAutoAnimate();

  return (
    <div ref={animationParent} className="flex flex-col gap-4 py-4">
      <p
        onClick={onToggle}
        className="flex justify-between gap-2 text-[14px] sm:text-[16px] font-[550]  cursor-pointer"
      >
        <span>{question}</span>
        <Image src={isOpen ? Minus : Plus} alt="Toggle" className="w-5 h-5" />
      </p>
      {isOpen && (
        <p className="text-[14px] sm:text-[16px] text-gray-900">{answer}</p>
      )}
    </div>
  );
};

// FAQ Component
export default function Faq() {
  const [openIndex, setOpenIndex] = useState(null);

  const toggleAccordion = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="lg:w-[95%] lg:mx-auto py-8 p-4">
      {/* Heading */}
      <h2 className="text-[22px] md:text-[28px] font-[700] text-[#16A8AF]   ">
        Andijan State Medical Institute - Important FAQs
      </h2>

      {/* FAQ List */}
      <div className="flex flex-col gap-2 md:gap-4 divide-y  w-[90%] md:w-[90%]  p-3 md:p-0">
        {faqs.map((faq, index) => (
          <Accordion
            key={index}
            question={faq.question}
            answer={faq.answer}
            isOpen={openIndex === index}
            onToggle={() => toggleAccordion(index)}
          />
        ))}
      </div>
    </div>
  );
}
