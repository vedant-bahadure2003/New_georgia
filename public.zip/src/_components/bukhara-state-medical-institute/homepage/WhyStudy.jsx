import React from "react";
import Image from "next/image";
import vector from "../../../../public/Images/vector.png";

const WhyStudy = () => {
  return (
    <>
      <div className="flex flex-col lg:flex-row lg:w-[95%] lg:mx-auto lg:justify-start items-center lg:items-start  ml-3 ">
        <div className=" flex flex-col py-6 bg-white">
          {/* Title */}
          <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]  ">
            Why Study MBBS At Bukhara State Medical Institute?
          </h2>

          {/* Description */}
          <p className="text-justify font-[550] text-[14px] sm:text-[16px]  pr-4 sm:pr-8 mt-2  ">
            Here are some key benefits of pursuing an MBBS degree at Bukhara
            State Medical Institute:
          </p>

          {/* Content Section */}
          <div className="text-[14px] sm:text-[16px] py-3 flex flex-col gap-3 sm:gap-4  pr-4 sm:pr-8">
            {[
              "The institute teaches students at a very affordable fee without compromising quality.",
              "The MBBS degree is recognised globally by the World Health Organisation (WHO) and the National Medical Commission (NMC).",
              "Students are taught high-quality medical education by dedicated, highly qualified instructors with teaching expertise.",
              "Classes are in English, making it easier for international students to understand the curriculum.",
              "With modern laboratories, classrooms, computer labs, and libraries that cater to the needs of the student.",
              "Safe dormitories, a wide range of food options, including Indian dishes, and easy documentation make it easy for international students.",
              "Students from diverse backgrounds create a very multicultural learning environment.",
            ].map((text, index) => (
              <div key={index} className="flex items-start gap-2">
                <Image
                  src={vector}
                  alt="vector"
                  className="h-[16px] w-[16px] sm:h-[18px] sm:w-[18px] mt-1"
                />
                <p className="text-justify">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default WhyStudy;
