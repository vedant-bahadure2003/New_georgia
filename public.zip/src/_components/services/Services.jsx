import React from "react";
import ServicesBgImg from "../../../public/Images/ServicesBgImg.png";
import ServicesImg from "../../../public/Images/ServiceImg.png";
import rafiki from "../../../public/Images/rafiki.png";
import Image from "next/image";

const Services = () => {
  // Array of services with title and subtitle
  const services = [
    {
      title: "Admission",
      subtitle: "Get guaranteed admission to top universities worldwide.",
      image: rafiki,
    },
    {
      title: "Visa Process",
      subtitle: "Streamline your visa application with expert assistance.",
      image: rafiki,
    },
    {
      title: "Accommodation",
      subtitle: "Secure and comfortable housing options for students.",
      image: rafiki,
    },
    {
      title: "Airport Pickup",
      subtitle: "Hassle-free airport pickup services for a smooth start.",
      image: rafiki,
    },
    {
      title: "Documentation",
      subtitle: "Comprehensive guidance for all your paperwork needs.",
      image: rafiki,
    },
    {
      title: "Free Counselling",
      subtitle: "Expert counselling to help you make informed decisions.",
      image: rafiki,
    },
  ];

  return (
    <>
      <div className="relative w-full h-[300px] sm:h-[380px] border border-black">
        {/* Background Images */}
        <div className="absolute h-[400px] w-full">
          <Image
            src={ServicesImg}
            alt="Services Image"
            className="w-full object-cover block sm:hidden h-[300px]"
          />
          <Image
            src={ServicesBgImg}
            alt="Services Background Image"
            className="w-full h-full object-cover hidden sm:block sm:h-[380px]"
          />
          <div className="h-[300px] sm:h-[380px] w-full absolute top-0 bg-black opacity-60"></div>
        </div>
        {/* Breadcrumb */}
        <div className="absolute top-20 sm:top-24 text-white left-5 lg:left-[10%] text-sm font-semibold">
          <p>
            Home /<span className="text-[#0da9b0]"> Services</span>
          </p>
        </div>
        {/* Heading */}
        <div className="text-white absolute top-32 sm:top-44 w-[90%] sm:w-[50%] left-5 lg:left-[10%] flex flex-col gap-1">
          <h1 className="text-[24px] sm:text-4xl font-semibold mt-3 w-full">
            Services
          </h1>
        </div>
      </div>

      {/* Services Cards */}
      <div className="w-full bg-[#c5ffff] p-10 flex flex-col gap-5 sm:gap-8 items-center justify-center">
        <div className="w-[90%] mx-auto text-center">
          <h2 className="text-[24px] sm:text-[40px] text-[#0da9b0] font-semibold">
            Our Services
          </h2>
        </div>
        <div className="w-[90%] mx-auto flex flex-wrap justify-center gap-6 items-center">
          {services.map((service, index) => (
            <div
              key={index}
              className="w-[311px] h-[302px] flex items-center justify-center flex-col gap-4 shadow-md rounded-xl bg-white"
            >
              <div className="w-[205px] h-[170px]">
                <Image
                  src={service.image}
                  alt={service.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex flex-col items-center justify-center gap-2">
                <h2 className="w-[80%] text-center font-semibold text-[20px] text-[#0da9b0]">
                  {service.title}
                </h2>
                <p className="w-[80%] text-center text-sm">
                  {service.subtitle}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Services;
