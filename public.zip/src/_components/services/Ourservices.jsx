import Image from "next/image";
import React from "react";
import Group from "../../../../public/Images/groupImg.png";

import service1 from "../../../public/Images/service1.png";
import service2 from "../../../public/Images/service2.png";
import service3 from "../../../public/Images/service3.png";
import service4 from "../../../public/Images/service4.png";
import service5 from "../../../public/Images/service5.png";
import service6 from "../../../public/Images/service6.png";

const Ourservices = () => {
  // Array of service images, titles, and subtitles
  const services = [
    {
      image: service1,
      title: "Admission",
      subtitle: "Secure your place at top universities.",
    },
    {
      image: service2,
      title: "Visa Assistance",
      subtitle: "We streamline your visa application process.",
    },
    {
      image: service3,
      title: "Career Guidance",
      subtitle: "Benefit from free counseling throughout your journey.",
    },
    {
      image: service4,
      title: "Documentation Support",
      subtitle: "We handle all your document legalization and verification.",
    },
    {
      image: service5,
      title: "Affordable Fees",
      subtitle: "Transparent and competitive fee structures for students.",
    },
    {
      image: service6,
      title: "Accommodation",
      subtitle:
        "We provide safe & comfortable dormitory stays for Indian students.",
    },
  ];

  return (
    <>
      <div className="mt-[40px]">
        <h2 className="text-[24px] sm:text-[40px] text-center font-semibold">
          Our Valuable{" "}
          <span className="text-[#0da9b0] underline">Services</span>
        </h2>
        <div className="w-[90%] sm:w-[80%] mx-auto flex flex-col sm:flex-row items-center justify-evenly gap-5 mt-[40px]">
          {/* Image Section */}
          <div className="hidden sm:block w-[500px] h-[488.47px]">
            <Image
              src={Group}
              alt="group"
              className="w-full h-full object-contain"
            />
          </div>

          {/* Services Section */}
          <div className="w-full sm:w-auto">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {services.map((service, index) => (
                <div
                  key={index}
                  className="flex flex-col items-center mx-8 gap-3 p-5 border-2 rounded-lg shadow-md shadow-gray-400 w-[85%] sm:w-[294px] h-[278px]"
                >
                  <div className="flex items-center justify-center bg-[#D1ECFF] rounded-full w-[110px] h-[110px]">
                    <Image
                      src={service.image}
                      alt={service.title}
                      className="w-[60px] h-[60px] sm:w-auto sm:h-auto"
                    />
                  </div>
                  <div>
                    <h3 className="text-[20px] sm:text-[24px] font-semibold text-[#0da9b0] text-center">
                      {service.title}
                    </h3>
                    <p className="text-sm text-center mt-3">
                      {service.subtitle}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex justify-center sm:justify-start">
              <button className="w-[140px] sm:w-[160px] h-[40px] mt-8 font-semibold text-white bg-[#0da9b0] rounded-full">
                Read More
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Ourservices;
