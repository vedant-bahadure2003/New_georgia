import Image from "next/image";
import React from "react";
import { PiArrowCircleUpRight } from "react-icons/pi";
import group from "../../public/Images/group.png";
import vector from "../../public/Images/vector.png";
import Head from "next/head";
import Link from "next/link";

const CurveImg = () => {
  return (
    <>
      {/* Desktop View */}
      <div className="hidden lg:flex w-full items-center justify-center mt-[30px] px-6 lg:px-0">
        <div className="w-full lg:w-[90%] h-auto flex flex-col-reverse lg:flex-row gap-8">
          {/* Text Section */}
          <div className="w-full lg:w-[50%] h-auto px-4 flex flex-col justify-center py-4">
            <div className="w-full lg:w-[75%] mx-auto">
              <div>
                <h2 className="text-[24px] sm:text-[36px] lg:text-[36px] font-semibold text-center lg:text-left">
                  Why{" "}
                  <span className="text-[#0da9b0] underline">
                    Uzbekistan Medi?
                  </span>
                </h2>

                <p className="text-[16px] mt-4 font-[500]  ">
                  Your trusted guide for MBBS admissions abroad. Offering
                  complete support, affordable fees, and guaranteed success!
                </p>
              </div>
              <div className="text-base sm:text-xl flex flex-col gap-2 mt-6">
                {[
                  "We primarily assist Indian students with pursuing medical education in Uzbekistan.",
                  "We provide end-to-end support, from choosing the right university to visa assistance.",
                  "With years of experience, we have built strong relationships with top medical universities in Uzbekistan.",
                  "Uzbekistan Medi maintains transparent & ethical practices throughout the entire application process.",
                ].map((text, index) => (
                  <div key={index} className="flex text-xl gap-2">
                    <Image
                      src={vector}
                      alt="Bullet point icon"
                      className="text-xl h-[25px] w-[25px] mt-1"
                    />
                    <p className="flex gap-2">{text}</p>
                  </div>
                ))}
              </div>
              <Link href="/about-us">
                <button
                  className="bg-[#0da9b0] w-[140px] sm:w-[160px] h-[40px] rounded-md text-white text-lg sm:text-xl font-semibold mx-auto mt-6 block"
                  aria-label="Read more about Uzbekistan Medi"
                >
                  Read More
                </button>
              </Link>
            </div>
          </div>

          {/* Image Section */}
          <div className="w-full lg:w-[50%] h-auto flex items-center justify-center relative py-8">
            <Image
              src={group}
              alt="Group of students or educational imagery"
              className="z-10 object-cover w-[350px] h-[350px] sm:w-[350px] sm:h-[350px] lg:w-[550px] lg:h-[550px] mx-auto"
              loading="lazy"
            />
          </div>
        </div>
      </div>

      {/* Mobile View */}
      <div className="lg:hidden w-full flex items-center justify-center mt-[30px] px-6">
        <div className="w-full h-auto flex flex-col ">
          <h2 className="text-[24px] sm:text-3xl lg:text-[30px] font-semibold text-center">
            Why{" "}
            <span className="text-[#0da9b0] underline">Uzbekistan Medi?</span>
          </h2>

          {/* Text Section */}
          <div className="w-full px-4 flex flex-col justify-center py-4">
            {/* Image Section */}
            <div className="w-full  h-auto flex items-center justify-center ">
              <Image
                src={group}
                alt="Group of students or educational imagery"
                className="z-10 object-cover w-[250px] h-[250px] sm:w-[300px] sm:h-[300px] mx-auto"
                loading="lazy"
              />
            </div>

            <p className="text-[16px] mt-4 font-[500] ">
              Your trusted guide for MBBS admissions abroad. Offering complete
              support, affordable fees, and guaranteed success!
            </p>

            <div className="text-[16px] sm:text-lg flex flex-col gap-2 mt-6">
              {[
                "We primarily assist Indian students with pursuing medical education in Uzbekistan.",
                "We provide end-to-end support, from choosing the right university to visa assistance.",
                "With years of experience, we have built strong relationships with top medical universities in Uzbekistan.",
                "Uzbekistan Medi maintains transparent & ethical practices throughout the entire application process.",
              ].map((text, index) => (
                <div key={index} className="flex text-lg gap-2">
                  <Image
                    src={vector}
                    alt="Bullet point icon"
                    className="text-xl h-[20px] w-[20px] mt-1"
                  />
                  <p className="flex gap-2">{text}</p>
                </div>
              ))}
            </div>

            <div className="w-[90%] mx-auto">
              <Link href="/about-us">
                <button
                  className="bg-[#0da9b0] w-[140px] h-[40px] rounded-md text-white text-lg font-semibold mx-auto mt-6 block"
                  aria-label="Read more about Uzbekistan Medi"
                >
                  Read More
                </button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CurveImg;
