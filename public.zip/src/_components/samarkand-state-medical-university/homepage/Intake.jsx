import React from "react";
import Image from "next/image";
import vector from "../../../../public/Images/vector.png";

const admissionData = [
  { event: "Application Start Date", date: "March 2025" },
  { event: "Application Deadline", date: "August 2025" },
  { event: "Program Commencement", date: "September 2025" },
  {
    event: "Admission Letter",
    date: "Issued within two weeks of the commencement date",
  },
];

const rankingData = { country: 3, world: 5827 };

const facilities = [
  "The college offers clubs and organisations for the arts, cultural activities, seminars, and workshops to enhance student learning and social life.",
  "There are modern lecture halls.",
  "Advanced laboratory facilities include simulation centres, internet, personal computers, anatomy rooms, and research labs for training in medicine.",
  "The library contains various resources in medical books, journals, and online access.",
  "The university library has a collection of 316,500 resources, comprising 57,262 e-books, and serves 11,023 users.",
  "An e-library allows access to 64,059 resources, 11,085 e-books, and serves 2,134 users.",
  "Clinics and regular medical check-ups are available for emergencies and student health.",
];

const Table = ({ data, headers }) => (
  <table className="w-full text-[14px] sm:text-[16px]text-left border border-black">
    <tbody>
      <tr className="bg-[#FFF7EE] border">
        {headers.map((header, index) => (
          <td
            key={index}
            className="px-4 py-2 border text-[14px] sm:text-[16px] border-black font-[550]"
          >
            {header}
          </td>
        ))}
      </tr>
      {data.map((row, index) => (
        <tr key={index} className="border">
          {Object.values(row).map((cell, i) => (
            <td
              key={i}
              className="px-4 py-2 border border-black text-[14px] sm:text-[16px] "
            >
              {cell}
            </td>
          ))}
        </tr>
      ))}
    </tbody>
  </table>
);

const Intake = () => {
  return (
    <>
      {/* Admission Dates & Deadlines */}
      <div className="lg:w-[95%] lg:mx-auto flex flex-col gap-3 py-6">
        <h2 className="text-[24px] font-[700] text-[#16A8AF]">
          Samarkand State Medical University - Admission Dates & Deadlines 2025
        </h2>
        <p className="text-[14px] sm:text-[16px] font-[550]">
          The intake dates for the 2025 - 2026 intake cycle at Samarkand State
          Medical University are as follows:
        </p>
        <Table data={admissionData} headers={["Events", "Dates"]} />
      </div>

      {/* Ranking */}
      <div className="lg:w-[95%] lg:mx-auto flex flex-col gap-3 py-6">
        <h2 className="text-[24px] font-[700] text-[#16A8AF]">
          Samarkand State Medical University Ranking
        </h2>
        <p className="text-sm font-semibold">
          According to 4icu.org, the following is the country and world ranking:
        </p>
        <Table
          data={[rankingData]}
          headers={["Country Ranking", "World Ranking"]}
        />
      </div>

      {/* Infrastructure and Facilities */}
      <div className="lg:w-[95%] lg:mx-auto flex flex-col py-6">
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#0da9b0]">
          Infrastructure & Facilities
        </h2>
        <p className="text-justify font-semibold text-[14px] sm:text-[16px] mt-3">
          The university offers study rooms, internet access, and advanced labs:
        </p>
        <div className="text-[14px] sm:text-[16px] py-3 flex flex-col gap-3 mt-4">
          {facilities.map((facility, index) => (
            <div key={index} className="flex items-start gap-2">
              <Image
                src={vector}
                alt="vector"
                className="h-[16px] w-[16px] sm:h-[18px] sm:w-[18px] mt-1"
              />
              <p className="text-justify">{facility}</p>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Intake;
