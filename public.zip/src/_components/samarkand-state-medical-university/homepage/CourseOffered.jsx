import React from "react";
import universityimg from "../../../../public/Images/hat.png";
import Image from "next/image";

const CourseOffered = () => {
  // Dynamic data for courses and durations
  const courses = [
    {
      name: "Samarkand State Medical University offers a wide range of medical programs catering to both undergraduate and postgraduate students. These include:",
      duration: "4 Years",
    },
    { name: "Nursing", duration: "4 Years" },
    { name: "Dentistry", duration: "4 Years" },
    { name: "Postgraduate Medical Programs", duration: "4 Years" },
    { name: "Pharmacy", duration: "4 Years" },
  ];

  return (
    <>
      {/* Accreditation Section */}
      <div className="bg-[#FFF9EA] ml-3 lg:w-[95%] lg:mx-auto md:p-12 p-6 rounded-md shadow-md shadow-gray-400">
        <h2 className="text-[#00a1ab] text-[22px] lg:text-[28px] font-[700] mb-4">
          Accreditation and Recognition of Samarkand State Medical University
        </h2>
        <p className="text-[14px] sm:text-[16px]">
          As a top medical university in Uzbekistan, Samarkand State Medical
          University is recognised and accredited by some of the most esteemed
          organisations in the world.
        </p>

        <div className="flex justify-center items-center mb-6">
          <div className="relative">
            <Image
              src={universityimg}
              alt="University Image"
              className="w-32 h-24 sm:w-44 sm:h-32"
            />
          </div>
        </div>

        <ul className="space-y-2 text-gray-800 text-[14px] sm:text-[16px]">
          <li className="flex items-start gap-2">
            <span className="text-yellow-500">⭐</span>
            United Nations Educational, Scientific, and Cultural Organization
            (UNESCO).
          </li>
          <li className="flex items-start gap-2">
            <span className="text-yellow-500">⭐</span>
            Foundation for Advancement of International Medical Education and
            Research (FAIMER).
          </li>
          <li className="flex items-start gap-2">
            <span className="text-yellow-500">⭐</span>
            The Ministry of Health of the Republic of Uzbekistan.
          </li>
          <li className="flex items-start gap-2">
            <span className="text-yellow-500">⭐</span>
            National Medical Commission (NMC).
          </li>
          <li className="flex items-start gap-2">
            <span className="text-yellow-500">⭐</span>
            World Health Organization (WHO).
          </li>
        </ul>
      </div>

      {/* Courses Offered Section */}
      <div className="px-4 lg:w-[95%] lg:mx-auto mt-[25px] md:px-0">
        <h2 className="text-[22px] lg:text-[28px] font-[700] text-[#16A8AF]  md:text-left">
          Courses Offered at Samarkand State Medical University
        </h2>
        <p className="text-[14px] sm:text-[16px] font-[550] mt-2 my-3  md:text-left">
          Samarkand State Medical University offers a wide range of medical
          programs catering to both undergraduate and postgraduate students.
          These include:
        </p>

        {/* Dynamic Courses Table */}
        <table className="w-full text-sm text-left rtl:text-right border border-black mt-5">
          <thead>
            <tr className="odd:bg-[#FFF7EE] even:bg-white border">
              <th className="px-4 py-2 border border-black text-[14px] sm:text-[16px] text-black text-center">
                Course Name
              </th>
              <th className="px-4 py-2 border border-black text-[14px] sm:text-[16px] text-black text-center">
                Duration
              </th>
            </tr>
          </thead>
          <tbody>
            {/* Map through courses array and display each course */}
            {courses.map((course, index) => (
              <tr
                key={index}
                className={`odd:bg-[#FFF7EE] even:bg-white border text-[14px] sm:text-[16px] ${
                  index % 2 === 0 ? "bg-[#FFF7EE]" : "bg-white"
                }`}
              >
                <td className="px-4 py-2 border border-black text-[14px] sm:text-[16px]">
                  {course.name}
                </td>
                <td className="px-4 py-2 border border-black text-[14px] sm:text-[16px]">
                  {course.duration}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default CourseOffered;
