import React from "react";

const FeesStructure = () => {
  // Dynamic data for courses and fees
  const coursesAndFees = [{ course: "MBBS", fee: "$24,000 USD" }];

  return (
    <div className="py-6 lg:w-[95%] lg:mx-auto flex justify-center ml-3 lg:justify-start">
      <div className="relative overflow-x-auto bg-white shadow-md rounded-md p-6">
        {/* Heading */}
        <h2 className="text-[22px] lg:text-[28px] font-bold text-[#16A8AF] mb-4">
          Samarkand State Medical University Fees 2025
        </h2>

        {/* Description */}
        <p className="text-justify text-[14px] sm:text-[16px] text-black mb-6">
          The fees for students at Samarkand State Medical University for a 6
          year MBBS course in Uzbekistan are around $24,000 USD. Studying at
          Samarkand State Medical University offers great value for Indian
          students, with affordable fees for both tuition and accommodation.
        </p>

        {/* Dynamic Courses and Fees Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-[14px] sm:text-[16px] text-left border border-black mt-5">
            <thead className="bg-[#FFF7EE] text-black">
              <tr>
                <th className="px-4 py-2 border border-black text-center font-semibold">
                  Course
                </th>
                <th className="px-4 py-2 border border-black text-center font-semibold">
                  Total Fees
                </th>
              </tr>
            </thead>
            <tbody>
              {/* Map through the courses and fees data */}
              {coursesAndFees.map((item, index) => (
                <tr
                  key={index}
                  className={`odd:bg-[#F8F9FA] even:bg-white ${
                    index % 2 === 0 ? "bg-[#F8F9FA]" : "bg-white"
                  }`}
                >
                  <td className="px-4 py-4 text-center border border-black">
                    {item.course}
                  </td>
                  <td className="px-4 py-4 text-center border border-black">
                    {item.fee}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Optional Button (If Needed) */}
        {/* <div className="mt-6 text-center">
          <button className="bg-[#00a1ab] text-white py-2 px-4 rounded-md text-[14px] sm:text-[16px]">
            <span className="font-medium">Read More:</span> Top Medical
            Universities in Uzbekistan
          </button>
        </div> */}
      </div>
    </div>
  );
};

export default FeesStructure;
