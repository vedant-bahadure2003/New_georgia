import React from "react";

const FeeStructure = () => {
  return (
    <div className="py-4 w-full lg:w-[95%] lg:mx-auto">
      <div className="py-6 w-full">
        <div className="relative overflow-x-auto mx-auto">
          {/* Title */}
          <h2 className="text-[24px] font-semibold text-[#16A8AF]  md:text-left">
            Samarkand State Medical University - MBBS Fee Structure 2025
          </h2>
          <p className="text-justify w-full text-sm sm:text-[14px] leading-5 py-3">
            Samarkand State Medical University provides an affordable MBBS fee
            structure and a range of specialized faculties to support diverse
            medical education needs. The total fee is approximately $24,000 USD
            for six years. <br />
            This cost-effective structure includes both tuition fees and hostel
            fees at the university. <br />
            The fee structure is provided in the table below:
          </p>

          {/* Responsive Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left mt-5 border-collapse">
              <thead>
                <tr className="bg-[#FFF7EE]">
                  <th className="px-4 py-2 border border-gray-400 text-black">
                    Year
                  </th>
                  <th className="px-4 py-2 border border-gray-400 text-black">
                    College Fee
                  </th>
                  <th className="px-4 py-2 border border-gray-400 text-black">
                    Hostel Fee
                  </th>
                </tr>
              </thead>
              <tbody>
                {[...Array(6)].map((_, index) => (
                  <tr key={index} className="bg-white">
                    <td className="px-4 py-2 border border-gray-400 font-semibold">
                      {index + 1}st Year
                    </td>
                    <td className="px-4 py-2 border border-gray-400">
                      3500 USD
                    </td>
                    <td className="px-4 py-2 border border-gray-400">
                      600 USD
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Note Section */}
          <div className="w-full bg-[#FFF7EE] mt-5 p-3 text-justify text-xs md:text-sm">
            <p>
              <strong>Note:</strong> The tuition fees for MBBS in Samarkand
              State Medical Institute mentioned above may change. Contact Select
              Your University to get the current fees for tuition, hostel, mess,
              & currency conversion.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeeStructure;
