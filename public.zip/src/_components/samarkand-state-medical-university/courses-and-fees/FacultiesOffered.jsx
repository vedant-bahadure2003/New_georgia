import Image from "next/image";
import React from "react";
import rightsign from "../../../../public/Images/vector.png";

const facultiesData = [
  {
    faculty: "Faculty of Medicine",
    subjects: [
      "General Medicine",
      "Anatomy",
      "Physiology",
      "Pathology",
      "Anesthesiology Resuscitation and Emergency Pediatrics",
      "Pharmacology and Clinical Pharmacology",
      "Pharmacology",
      "Nanomedicine",
      "Obstetrics and Gynecology",
      "Children's Traumatology, Orthopedics and Neurosurgery",
      "Ophthalmology",
      "Microbiology",
      "Community Medicine",
      "Obstetrics and Gynecology",
      "Children's Traumatology, Orthopedics and Neurosurgery",
      "Medical Ethics",
    ],
  },
  {
    faculty: "Faculty of Dentistry",
    subjects: [
      "Dental Anatomy",
      "Oral Pathology",
      "Prosthodontics",
      "Anesthesiology Resuscitation and Emergency Pediatrics",
      "Pharmacology and Clinical Pharmacology",
      "Orthodontics",
      "Endodontics",
      "Oral Surgery",
      "Periodontology",
      "Nanomedicine",

      "Obstetrics and Gynecology",
      "Children's Traumatology, Orthopedics and Neurosurgery",
      "Ophthalmology",
      "Pedodontics",
    ],
  },
  {
    faculty: "Faculty of Pharmacy",
    subjects: [
      "Pharmaceutical Chemistry",
      "Pharmacognosy",
      "Biochemistry",
      "Medicinal Chemistry",
      "Clinical Pharmacy",
      "Pharmacokinetics",
      "Pharmaceutical Jurisprudence",
      "Toxicology",
      "Nanomedicine",
      "Anesthesiology Resuscitation and Emergency Pediatrics",
      "Pharmacology and Clinical Pharmacology",
      "Obstetrics and Gynecology",
      "Children's Traumatology, Orthopedics and Neurosurgery",
      "Ophthalmology",
    ],
  },
  {
    faculty: "Faculty of Nursing",
    subjects: [
      "Fundamentals of Nursing",
      "Medical-Surgical Nursing",
      "Pediatric Nursing",
      "Psychiatric Nursing",
      "Community Health Nursing",
      "Maternity Nursing",
      "Pharmacology for Nurses",
      "Nutrition and Dietetics",
      "Nanomedicine",
      "Anesthesiology Resuscitation and Emergency Pediatrics",
      "Pharmacology and Clinical Pharmacology",
      "Obstetrics and Gynecology",
      "Children's Traumatology, Orthopedics and Neurosurgery",
      "Ophthalmology",
    ],
  },
  {
    faculty: "Faculty of Public Health",
    subjects: [
      "Epidemiology",
      "Biostatistics",
      "Environmental Health",
      "Occupational Health",
      "Health Policy & Management",
      "Community Nutrition",
      "Mental Health",
      "Global Health Issues",
      "Nanomedicine",
      "Anesthesiology Resuscitation and Emergency Pediatrics",
      "Pharmacology and Clinical Pharmacology",
      "Obstetrics and Gynecology",
      "Children's Traumatology, Orthopedics and Neurosurgery",
      "Ophthalmology",
    ],
  },
  {
    faculty: "Faculty of Medical Research",
    subjects: [
      "Biomedical Research Methods",
      "Clinical Trials",
      "Genetic Research",
      "Military Training and Civil Protection",
      "Stem Cell Technology",
      "Molecular Biology",
      "Bioinformatics",
      "Immunology Research",
      "Nanomedicine",
      "Anesthesiology Resuscitation and Emergency Pediatrics",
      "Pharmacology and Clinical Pharmacology",
      "Obstetrics and Gynecology",
      "Children's Traumatology, Orthopedics and Neurosurgery",
      "Ophthalmology",
    ],
  },
];

const FacultiesOffered = () => {
  return (
    <div className="  lg:w-[95%] lg:mx-auto">
      <div className="w-full   py-6">
        <h2 className=" sm:text-xl text-[24px] font-[700] text-[#0da9b0] mb-4">
          Faculties of Samarkand State Medical Institute
        </h2>

        {/* Faculty Boxes */}
        <div className=" flex flex-col sm:ml-0  ml-4  gap-5 w-full ">
          {facultiesData.map((faculty, index) => (
            <div
              key={index}
              className="w-[90%]   min-h-[500px]  flex flex-col justify-start bg-white shadow-md shadow-gray-400  p-4 border  rounded-md"
            >
              {/* Faculty Title */}
              <p className="font-semibold pb-3  text-lg sm:text-xl">
                {index + 1}. {faculty.faculty}
              </p>

              {/* Subject List - Evenly Distributed */}
              <div className="flex flex-col justify-between h-full space-y-2 sm:space-y-3 md:space-y-4">
                {faculty.subjects.map((subject, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <Image
                      src={rightsign}
                      alt="checkmark"
                      className="w-4 h-4"
                    />
                    <p className="text-xs sm:text-sm">{subject}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FacultiesOffered;
