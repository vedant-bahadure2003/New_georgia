import Image from "next/image";
import onlineAppIcon from "../../../../public/Images/online-application.png";
import submitIcon from "../../../../public/Images/submit.png";
import reviewIcon from "../../../../public/Images/review.png";
import acceptIcon from "../../../../public/Images/accept.png";
import visaIcon from "../../../../public/Images/visa.png";

const admissionSteps = [
  {
    title: "Make an online application :",
    description:
      "Complete an online form and upload the necessary paperwork as stated above.",
    icon: onlineAppIcon,
  },
  {
    title: "Submit the application :",
    description:
      "Upon your submission of the application, wait for the university to review your application.",
    icon: submitIcon,
  },
  {
    title: "Application review by government authorities:",
    description:
      "If chosen, your application will be forwarded to the government agencies for further examination so that you can obtain an invitation letter and the necessary paperwork for your visa application.",
    icon: reviewIcon,
  },
  {
    title: "Acceptance letter from University:",
    description:
      "The University will provide you an official acceptance letter so you may start your visa application after the Government office confirms your admission.",
    icon: acceptIcon,
  },
  {
    title: "Visa Application:",
    description:
      "You must deliver all of your educational documentation to the Uzbek embassy or consulate along with the university's and country's government's acknowledgement or paperwork.",
    icon: visaIcon,
  },
];

const AdmissionProcess = () => {
  return (
    <div className="lg:w-[95%] lg:mx-auto py-4 w-full ml-2 p-4   ">
      <div className=" py-6 ">
        {/* Heading */}
        <h2 className="text-[24px] md:text-2xl font-bold text-[#0da9b0]">
          How to Take Admission in Samarkand State Medical University?
        </h2>
        <p className="mt-2 text-[14px] text-justify md:text-[16px] text-gray-700">
          MBBS admission at Samarkand State Medical University operates through
          an uncomplicated application path. Prospective students need to fill
          out the online application form found on the university website, which
          requires document uploads. The administrative staff of the university
          reviews your application before issuing an admission decision within
          48 hours.
          <br /> <br />
          Your application for a visa depends on two requirements: payment of
          the initial first-year classes and verification of valid passport
          status. The visa application process requires 30 days before visa
          approval is obtained to allow students to book their next trip. You
          must present your documents at the university’s admission office to
          finish your enrollment process. .
        </p>

        {/* Steps Section */}
        <div className="mt-6 flex flex-col gap-6">
          {admissionSteps.map((step, index) => (
            <div key={index} className="flex gap-4 items-start">
              <Image
                src={step.icon}
                alt="step icon"
                width={40}
                height={40}
                className="h-[32px] w-[32px] md:h-[40px] md:w-[40px] mt-1"
              />
              <div>
                <h3 className="font-semibold text-[14px] md:text-[16px]">
                  {step.title}
                </h3>
                <p className="text-[14px] text-justify md:text-[16px] text-gray-700">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AdmissionProcess;
