import React from "react";
import Image from "next/image";
import Link from "next/link";
import admission from "../../public/Images/admission.png";
import airport from "../../public/Images/airport.png";
import visaprocess from "../../public/Images/visaprocess.png";
import documentation from "../../public/Images/documentation.png";
import accommodation from "../../public/Images/accomodation.png";
import councelling from "../../public/Images/councelling.png";

const Services = () => {
  // Services data including images
  const services = [
    {
      title: "Admission Assistance",
      description: "Secure your place at top universities.",
      image: admission,
    },
    {
      title: "Visa Processing",
      description: "We streamline your visa application process.",
      image: visaprocess,
    },
    {
      title: "Accommodation",
      description:
        "We provide safe & comfortable dormitory stays for Indian students.",
      image: accommodation,
    },
    {
      title: "Airport Pickup",
      description: "We will greet you at the airport upon arrival.",
      image: airport,
    },
    {
      title: "Documentation",
      description: "We handle all your document legalization and verification.",
      image: documentation,
    },
    {
      title: "Free Counseling",
      description: "Benefit from free counseling throughout your journey.",
      image: councelling,
    },
  ];

  return (
    <section
      className="bg-gradient-to-br from-[#D9D9D9] to-[#02D6E1] py-[50px]"
      aria-labelledby="services-title"
    >
      <header className="text-center">
        <h2
          id="services-title"
          className="text-[24px] sm:text-[36px] font-[700]"
        >
          Our Valuable{" "}
          <span className="text-[#16A8AF] underline">Services</span>
        </h2>
        <p className="text-black text-[14px] sm:text-[16px] lg:text-[18px] mt-2">
          Providing comprehensive assistance throughout your journey.
        </p>
      </header>

      <div
        className="flex gap-12  flex-wrap w-[80%] mx-auto items-center justify-center mt-8"
        aria-label="List of services"
      >
        {services.map((service, index) => (
          <article
            key={index}
            className="bg-white flex flex-col rounded-xl items-center justify-between p-6 w-[300px] h-[280px] sm:h-[300px]  shadow-md shadow-gray-400 border border-[#e0e0e0]"
          >
            {/* Service Image */}
            <div className="w-[150px] h-[100px]">
              <Image
                src={service.image}
                alt={service.title}
                className=" w-[200px] h-[160px] "
              />
            </div>

            {/* Service Title */}
            <h3 className="text-[18px]  mt-14   sm:text-[20px] font-semibold text-[#16A8AF] text-center">
              {service.title}
            </h3>

            {/* Service Description */}
            <p className="text-center  text-[14px] sm:text-[16px] text-gray-700 ">
              {service.description}
            </p>
          </article>
        ))}
      </div>

      <div className="w-full flex items-center mt-6 justify-center">
        <Link href="/our-services">
          <button className="bg-[#16A8AF] px-4 py-1.5 w-[130px] sm:w-[150px] h-[40px] rounded-md text-white text-[16px] sm:text-[18px] font-semibold mb-[50px]">
            Read More
          </button>
        </Link>
      </div>
    </section>
  );
};

export default Services;
