"use client"; // Add this line to mark this component as a client-side component

import Image from "next/image";
import vector from "../../public/Images/vector.png";
import whyStudy from "../../public/Images/whyStudy.png";
import Link from "next/link";

const WhyStudy = () => {
  return (
    <section
      className="bg-white py-8 lg:py-10 px-3 lg:px-10"
      aria-labelledby="why-study-title"
    >
      {/* Mobile View */}
      <div className="block lg:hidden">
        <h2
          id="why-study-title"
          className="text-[24px] w-full  font-[700] text-gray-800 text-center mb-4 whitespace-nowrap"
        >
          Why Study MBBS in <br />
          <span className="text-[#0da9b0] underline">Uzbekistan?</span>
        </h2>

        {/* The rest of the content remains unchanged */}

        {/* Text Section */}
        <div className="w-full flex flex-col gap-5">
          {/* Image Section */}
          <div className="relative  w-full mb-6">
            <Image
              src={whyStudy}
              alt="Doctor explaining why to study in Uzbekistan"
              className="w-full h-auto object-contain"
              priority
            />
          </div>

          <ul className="text-[16px] flex flex-col gap-4 mx-auto">
            {[
              "Get a high-quality medical degree at significantly lower costs compared to other countries.",
              "Study medicine entirely in English, making it easier for international students.",
              "Your Uzbek medical degree will be respected and accepted worldwide.",
              "Uzbek medical universities have a strong academic reputation & provide excellent medical training.",
              "Experience a welcoming and secure environment for your studies in Uzbekistan.",
              "Gain valuable practical experience through clinical rotations in modern hospitals.",
            ].map((text, index) => (
              <li key={index} className="flex gap-3 items-start">
                <Image
                  src={vector}
                  alt="Checkmark icon for important feature"
                  className="h-[20px] w-[20px] mt-1"
                />
                <span>{text}</span>
              </li>
            ))}
          </ul>

          <div className="w-[90%] mx-auto">
            <Link href="/mbbs-in-uzbekistan">
              <button
                className="bg-[#0da9b0] w-[140px] h-[40px] rounded-md text-white text-lg font-semibold mx-auto mt-6 block"
                aria-label="Read more about Uzbekistan Medi"
              >
                Read More
              </button>
            </Link>
          </div>
        </div>
      </div>

      {/* Desktop View */}
      <div className="hidden lg:flex flex-row items-center justify-between gap-16">
        {/* Image Section */}
        <div className="relative w-[60%] max-w-[750px] mx-auto overflow-hidden mb-6 md:mb-0">
          <Image
            src={whyStudy}
            alt="Doctor explaining why to study in Uzbekistan"
            className="w-full h-auto max-h-[600px] object-contain"
            priority
          />
        </div>

        {/* Text Section */}
        <div className="w-[70%] mx-auto flex flex-col gap-5">
          <h2
            id="why-study-title"
            className="text-[24px] lg:text-[36px] font-[700] text-gray-800 text-center"
          >
            Why Study MBBS in
            <span className="text-[#0da9b0] underline">Uzbekistan?</span>
          </h2>

          <ul className="text-[18px] flex flex-col gap-4 mx-auto">
            {[
              "Get a high-quality medical degree at significantly lower costs compared to other countries.",
              "Study medicine entirely in English, making it easier for international students.",
              "Your Uzbek medical degree will be respected and accepted worldwide.",
              "Uzbek medical universities have a strong academic reputation & provide excellent medical training.",
              "Experience a welcoming and secure environment for your studies in Uzbekistan.",
              "Gain valuable practical experience through clinical rotations in modern hospitals.",
            ].map((text, index) => (
              <li key={index} className="flex gap-3 items-start">
                <Image
                  src={vector}
                  alt="Checkmark icon for important feature"
                  className="h-[20px] w-[20px] mt-1"
                />
                <span>{text}</span>
              </li>
            ))}
          </ul>

          <div className="w-[70%] mx-auto">
            <Link href="/mbbs-in-uzbekistan">
              <button
                className="bg-[#0da9b0] w-[160px] h-[40px] rounded-md text-white text-xl font-semibold mx-auto mt-6 block"
                aria-label="Read more about Uzbekistan Medi"
              >
                Read More
              </button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyStudy;
